// ============================================
// THCpanel - Main Application
// ============================================

import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import Login from '@/pages/Login';
import Dashboard from '@/pages/Dashboard';
import Queries from '@/pages/Queries';
import Market from '@/pages/Market';
import UsersPage from '@/pages/Users';
import AdminPanel from '@/pages/AdminPanel';
import Profile from '@/pages/Profile';
import Sidebar from '@/components/Sidebar';
import ChatWidget from '@/components/ChatWidget';
import { initDatabase } from '@/utils/database';

function App() {
  const { isAuthenticated, user, loading, login, logout, register, refreshUser } = useAuth();
  const [currentPage, setCurrentPage] = useState('home');

  useEffect(() => {
    initDatabase();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#020204] flex items-center justify-center">
        <div className="cyber-loading" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Login onLogin={login} onRegister={register} />;
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <Dashboard user={user} />;
      case 'free-queries':
      case 'premium-queries':
        return <Queries user={user} />;
      case 'market':
        return <Market user={user} onUserUpdate={refreshUser} />;
      case 'users':
        return <UsersPage />;
      case 'profile':
        return <Profile user={user} onUserUpdate={refreshUser} />;
      case 'admin':
      case 'logs':
      case 'memberships':
      case 'permissions':
      case 'security':
        return <AdminPanel user={user} />;
      default:
        return <Dashboard user={user} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#020204] flex">
      <Sidebar
        user={user}
        currentPage={currentPage}
        onPageChange={setCurrentPage}
        onLogout={logout}
      />
      <main className="flex-1 overflow-auto relative">
        {renderPage()}
      </main>
      {/* Chat Widget - Only show for approved users */}
      {user?.isApproved && <ChatWidget currentUser={user} />}
    </div>
  );
}

export default App;
