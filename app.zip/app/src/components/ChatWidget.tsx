// ============================================
// THCpanel - Encrypted Chat Widget
// ============================================

import { useState, useEffect, useRef } from 'react';
import { MessageCircle, X, Send, Lock, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import type { User, ChatMessage } from '@/types';
import { getChatMessages, addChatMessage, getUsers } from '@/utils/database';

interface ChatWidgetProps {
  currentUser: User | null;
}

export default function ChatWidget({ currentUser }: ChatWidgetProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [onlineUsers, setOnlineUsers] = useState(0);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Load messages
  useEffect(() => {
    if (isOpen) {
      setMessages(getChatMessages());
      
      // Count "online" users (users who logged in today)
      const users = getUsers();
      const today = new Date().toDateString();
      const online = users.filter(u => 
        u.lastLogin && new Date(u.lastLogin).toDateString() === today
      ).length;
      setOnlineUsers(online || 1);
    }
  }, [isOpen]);

  // Auto-refresh messages
  useEffect(() => {
    if (isOpen) {
      intervalRef.current = setInterval(() => {
        setMessages(getChatMessages());
      }, 3000);
    }
    
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isOpen]);

  // Scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = () => {
    if (!newMessage.trim() || !currentUser) return;

    addChatMessage({
      userId: currentUser.id,
      username: currentUser.username,
      avatar: currentUser.avatar,
      message: newMessage.trim()
    });

    setNewMessage('');
    setMessages(getChatMessages());
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <>
      {/* Chat Toggle Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-gradient-to-br from-[#00ffff] to-[#ff00ff] rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform"
        >
          <MessageCircle className="w-6 h-6 text-black" />
          {messages.length > 0 && (
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full text-xs flex items-center justify-center text-white font-bold">
              {messages.length > 99 ? '99+' : messages.length}
            </span>
          )}
        </button>
      )}

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-6 right-6 z-50 w-80 md:w-96 bg-[#020204] border border-[#00ffff]/50 rounded-xl overflow-hidden shadow-2xl">
          {/* Header */}
          <div className="bg-gradient-to-r from-[#00ffff]/20 to-[#ff00ff]/20 p-4 border-b border-[#00ffff]/30 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <MessageCircle className="w-5 h-5 text-[#00ffff]" />
              <span className="text-white font-mono font-bold">SOHBET</span>
              <div className="flex items-center gap-1 text-xs text-[#00ff00]">
                <Users className="w-3 h-3" />
                <span>{onlineUsers}</span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1 text-xs text-[#00ff00]">
                <Lock className="w-3 h-3" />
                <span>SIFRELI</span>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1 hover:bg-white/10 rounded"
              >
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>
          </div>

          {/* Messages */}
          <div className="h-80 overflow-y-auto p-4 space-y-3">
            {messages.length === 0 ? (
              <div className="text-center text-slate-500 py-8">
                <MessageCircle className="w-12 h-12 mx-auto mb-2 opacity-30" />
                <p className="text-sm font-mono">Heniz mesaj yok</p>
                <p className="text-xs">Ilk mesaji siz gonderin!</p>
              </div>
            ) : (
              messages.map((msg) => {
                const isOwn = msg.userId === currentUser?.id;
                
                return (
                  <div
                    key={msg.id}
                    className={`flex gap-2 ${isOwn ? 'flex-row-reverse' : ''}`}
                  >
                    {/* Avatar */}
                    <div className="w-8 h-8 rounded bg-gradient-to-br from-[#00ffff] to-[#ff00ff] flex items-center justify-center text-black text-xs font-bold flex-shrink-0">
                      {msg.avatar ? (
                        <img src={msg.avatar} alt="" className="w-full h-full rounded object-cover" />
                      ) : (
                        msg.username.charAt(0).toUpperCase()
                      )}
                    </div>
                    
                    {/* Message */}
                    <div className={`max-w-[70%] ${isOwn ? 'text-right' : ''}`}>
                      <div className="text-[10px] text-slate-500 mb-0.5 font-mono">
                        {msg.username}
                      </div>
                      <div
                        className={`inline-block px-3 py-2 rounded-lg text-sm ${
                          isOwn
                            ? 'bg-[#00ffff]/20 text-[#00ffff] border border-[#00ffff]/30'
                            : 'bg-white/5 text-slate-300 border border-white/10'
                        }`}
                      >
                        {msg.message}
                      </div>
                      <div className="text-[9px] text-slate-600 mt-0.5">
                        {new Date(msg.timestamp).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-3 border-t border-[#00ffff]/30 bg-black/50">
            <div className="flex gap-2">
              <Input
                type="text"
                value={newMessage}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Mesaj yazin..."
                className="flex-1 bg-black/50 border-[#00ffff]/50 text-white placeholder:text-slate-600 text-sm font-mono"
              />
              <Button
                onClick={handleSend}
                disabled={!newMessage.trim()}
                className="px-3 bg-[#00ffff] text-black hover:bg-[#00ffff]/80 disabled:opacity-50"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
            <div className="text-[9px] text-slate-600 mt-1 text-center">
              Tum mesajlar uctan uca sifrelenmistir
            </div>
          </div>
        </div>
      )}
    </>
  );
}
