// ============================================
// THCpanel - Sidebar Component
// ============================================

import { useState } from 'react';
import {
  Home,
  Search,
  Users,
  Shield,
  LogOut,
  ChevronRight,
  ChevronDown,
  Database,
  CreditCard,
  Crown,
  Gem,
  Activity,
  Zap,
  Terminal,
  Lock,
  Radio,
  User as UserIcon,
  MessageCircle,
  AlertTriangle
} from 'lucide-react';
import type { User } from '@/types';
import { hasPermission, canViewIpLogs, TELEGRAM_CONTACT, getPendingUsers } from '@/utils/database';

interface SidebarProps {
  user: User | null;
  currentPage: string;
  onPageChange: (page: string) => void;
  onLogout: () => void;
}

interface MenuItem {
  id: string;
  label: string;
  icon: React.ElementType;
  permission?: string;
  badge?: number;
  submenu?: { id: string; label: string; permission?: string }[];
}

export default function Sidebar({ user, currentPage, onPageChange, onLogout }: SidebarProps) {
  const [expandedMenus, setExpandedMenus] = useState<string[]>(['queries']);
  
  const pendingCount = user?.role === 'founder' || user?.role === 'admin' 
    ? getPendingUsers().length 
    : 0;

  const menuItems: MenuItem[] = [
    { id: 'home', label: 'DASHBOARD', icon: Home },
    {
      id: 'queries',
      label: 'SORGULAR',
      icon: Search,
      permission: 'queries.view',
      submenu: [
        { id: 'free-queries', label: 'UCRETSIZ', permission: 'queries.free' },
        { id: 'premium-queries', label: 'PREMIUM', permission: 'queries.premium' },
      ]
    },
    { id: 'market', label: 'MARKET', icon: CreditCard, permission: 'market.view' },
    { id: 'users', label: 'KULLANICILAR', icon: Users, permission: 'users.view' },
    { id: 'profile', label: 'PROFILIM', icon: UserIcon },
    {
      id: 'admin',
      label: 'ADMIN PANEL',
      icon: Shield,
      permission: 'admin.view',
      badge: pendingCount,
      submenu: [
        { id: 'logs', label: 'SISTEM LOG', permission: 'admin.logs' },
        { id: 'memberships', label: 'UYELIKLER', permission: 'admin.memberships' },
        { id: 'permissions', label: 'YETKILER', permission: 'admin.permissions' },
        { id: 'security', label: 'GUVENLIK', permission: 'admin.security' },
      ]
    },
  ];

  const toggleMenu = (menuId: string) => {
    setExpandedMenus(prev =>
      prev.includes(menuId)
        ? prev.filter(id => id !== menuId)
        : [...prev, menuId]
    );
  };

  const getRoleBadge = (role: string) => {
    switch (role) {
      case 'founder':
        return { color: 'from-[#ff0040] to-[#ff4000]', icon: Crown, label: 'FOUNDER' };
      case 'admin':
        return { color: 'from-[#ff00ff] to-[#ff40ff]', icon: Shield, label: 'ADMIN' };
      case 'vendor':
        return { color: 'from-[#00ff00] to-[#40ff40]', icon: Zap, label: 'VENDOR' };
      case 'moderator':
        return { color: 'from-[#0080ff] to-[#4080ff]', icon: Users, label: 'MOD' };
      case 'elmas':
        return { color: 'from-[#00ffff] to-[#40ffff]', icon: Gem, label: 'ELMAS' };
      case 'vip':
        return { color: 'from-[#ffff00] to-[#ffff40]', icon: Crown, label: 'VIP' };
      default:
        return { color: 'from-slate-600 to-slate-500', icon: Activity, label: 'USER' };
    }
  };

  const roleBadge = user ? getRoleBadge(user.role) : null;
  const showIpLogs = canViewIpLogs(user);

  const canAccessMenuItem = (item: MenuItem): boolean => {
    if (!item.permission) return true;
    return hasPermission(user, item.permission);
  };

  const canAccessSubmenu = (submenu: { permission?: string }): boolean => {
    if (!submenu.permission) return true;
    return hasPermission(user, submenu.permission);
  };

  return (
    <div className="w-80 h-screen bg-[#020204] border-r border-[#00ffff]/30 flex flex-col relative overflow-hidden">
      {/* Background Grid */}
      <div 
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: `
            linear-gradient(rgba(0, 255, 255, 0.2) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255, 0, 255, 0.2) 1px, transparent 1px)
          `,
          backgroundSize: '30px 30px'
        }}
      />

      {/* Glow Effect */}
      <div className="absolute top-0 right-0 w-32 h-full bg-gradient-to-l from-[#00ffff]/5 to-transparent pointer-events-none" />

      {/* Logo */}
      <div className="p-6 border-b border-[#00ffff]/30 relative">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="absolute -inset-2 bg-gradient-to-r from-[#00ffff] to-[#ff00ff] rounded-lg blur opacity-50 animate-pulse" />
            <div className="relative w-12 h-12 bg-gradient-to-br from-[#00ffff] to-[#ff00ff] rounded-lg flex items-center justify-center">
              <Terminal className="w-6 h-6 text-black" />
            </div>
          </div>
          <div>
            <h1 className="text-2xl font-bold">
              <span className="text-[#00ffff]">THC</span>
              <span className="text-[#ff00ff]">panel</span>
            </h1>
            <p className="text-[10px] text-[#00ffff] font-mono tracking-widest">v2.0.0-SECURE</p>
          </div>
        </div>
      </div>

      {/* User Info Card */}
      <div className="p-4 mx-4 mt-4 relative">
        <div className="absolute -inset-0.5 bg-gradient-to-r from-[#00ffff]/50 to-[#ff00ff]/50 rounded-lg blur opacity-30" />
        <div className="relative bg-black/80 border border-[#00ffff]/50 rounded-lg p-4">
          {/* Corner Decorations */}
          <div className="absolute top-0 left-0 w-3 h-3 border-t border-l border-[#00ffff]" />
          <div className="absolute top-0 right-0 w-3 h-3 border-t border-r border-[#ff00ff]" />
          <div className="absolute bottom-0 left-0 w-3 h-3 border-b border-l border-[#ff00ff]" />
          <div className="absolute bottom-0 right-0 w-3 h-3 border-b border-r border-[#00ffff]" />

          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded bg-gradient-to-br from-[#00ffff] to-[#ff00ff] flex items-center justify-center text-black font-bold text-lg overflow-hidden">
              {user?.avatar ? (
                <img src={user.avatar} alt="" className="w-full h-full object-cover" />
              ) : (
                user?.username.charAt(0).toUpperCase()
              )}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-white font-mono text-sm truncate">{user?.username}</p>
              {roleBadge && (
                <div className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold text-black bg-gradient-to-r ${roleBadge.color}`}>
                  <roleBadge.icon className="w-3 h-3" />
                  {roleBadge.label}
                </div>
              )}
            </div>
          </div>

          {/* Level & XP */}
          {user && (
            <div className="mt-3 pt-3 border-t border-[#00ffff]/20">
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="text-slate-500 font-mono">SEVIYE {user.level}</span>
                <span className="text-[#00ffff] font-mono">{user.xp.toLocaleString()} XP</span>
              </div>
              <div className="h-1 bg-black/50 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-[#00ffff] to-[#ff00ff]"
                  style={{ width: `${Math.min((user.xp % 1000) / 10, 100)}%` }}
                />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Pending Approval Warning */}
      {pendingCount > 0 && (user?.role === 'founder' || user?.role === 'admin') && (
        <div className="mx-4 mt-4 p-3 bg-[#ffff00]/10 border border-[#ffff00]/50 rounded-lg">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-[#ffff00]" />
            <span className="text-[#ffff00] text-xs font-mono">
              {pendingCount} ONAY BEKLIYOR
            </span>
          </div>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1 relative">
        {menuItems.map((item) => {
          if (!canAccessMenuItem(item)) return null;

          const Icon = item.icon;
          const isExpanded = expandedMenus.includes(item.id);
          const isActive = currentPage === item.id || item.submenu?.some(sub => sub.id === currentPage);

          return (
            <div key={item.id}>
              <button
                onClick={() => {
                  if (item.submenu) {
                    toggleMenu(item.id);
                  } else {
                    onPageChange(item.id);
                  }
                }}
                className={`w-full flex items-center gap-3 px-3 py-3 rounded transition-all duration-200 font-mono text-sm ${
                  isActive
                    ? 'bg-gradient-to-r from-[#00ffff]/20 to-[#ff00ff]/20 text-white border border-[#00ffff]/50'
                    : 'text-slate-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'text-[#00ffff]' : ''}`} />
                <span className="flex-1 text-left">{item.label}</span>
                {item.badge && item.badge > 0 && (
                  <span className="px-2 py-0.5 bg-[#ff0040] text-white text-[10px] rounded-full">
                    {item.badge}
                  </span>
                )}
                {item.submenu && (
                  isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />
                )}
              </button>

              {item.submenu && isExpanded && (
                <div className="ml-4 mt-1 space-y-1 border-l-2 border-[#00ffff]/30 pl-3">
                  {item.submenu.map((sub) => {
                    if (!canAccessSubmenu(sub)) return null;
                    if (sub.id === 'logs' && !showIpLogs) return null;

                    return (
                      <button
                        key={sub.id}
                        onClick={() => onPageChange(sub.id)}
                        className={`w-full flex items-center gap-2 px-3 py-2 rounded transition-all duration-200 text-sm font-mono ${
                          currentPage === sub.id
                            ? 'bg-[#00ffff]/20 text-[#00ffff] border border-[#00ffff]/30'
                            : 'text-slate-500 hover:text-slate-300 hover:bg-white/5'
                        }`}
                      >
                        <Database className="w-3 h-3" />
                        {sub.label}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </nav>

      {/* Security Status */}
      <div className="p-4 border-t border-[#00ffff]/20">
        <div className="flex items-center gap-2 mb-2">
          <Lock className="w-3 h-3 text-[#00ff00]" />
          <span className="text-[10px] text-[#00ff00] font-mono">ENC: AES-256</span>
        </div>
        <div className="flex items-center gap-2 mb-2">
          <Radio className="w-3 h-3 text-[#00ffff]" />
          <span className="text-[10px] text-[#00ffff] font-mono">IP MASK: AKTIF</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 bg-[#00ff00] rounded-full animate-pulse" />
          <span className="text-[10px] text-[#00ff00] font-mono">SYSTEM ONLINE</span>
        </div>
      </div>

      {/* Contact */}
      <div className="px-4 pb-2">
        <a 
          href={`https://t.me/${TELEGRAM_CONTACT}`}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center justify-center gap-2 p-2 bg-[#0088cc]/20 border border-[#0088cc]/50 rounded text-[#0088cc] text-xs font-mono hover:bg-[#0088cc]/30 transition-colors"
        >
          <MessageCircle className="w-3 h-3" />
          @{TELEGRAM_CONTACT}
        </a>
      </div>

      {/* Logout */}
      <div className="p-4 border-t border-[#00ffff]/20">
        <button
          onClick={onLogout}
          className="w-full flex items-center gap-3 px-3 py-3 rounded text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-all duration-200 font-mono text-sm border border-transparent hover:border-red-500/30"
        >
          <LogOut className="w-5 h-5" />
          <span>[ CIKIS ]</span>
        </button>
      </div>
    </div>
  )}
