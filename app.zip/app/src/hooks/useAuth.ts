// ============================================
// THCpanel - Authentication Hook
// ============================================

import { useState, useEffect, useCallback } from 'react';
import type { AuthState } from '@/types';
import {
  getCurrentUser,
  createSession,
  clearSession,
  getUserByUsername,
  addLog,
  generateId,
  createUser,
  initDatabase,
  updateUser,
  recordFailedLogin,
  resetLoginAttempts,
  isAccountLocked,
  validateSession
} from '@/utils/database';

export const useAuth = () => {
  const [authState, setAuthState] = useState<AuthState>({
    isAuthenticated: false,
    user: null,
    token: null
  });
  const [loading, setLoading] = useState(true);
  const [pendingApproval, setPendingApproval] = useState(false);

  useEffect(() => {
    initDatabase();
    
    // Check for existing session
    const user = getCurrentUser();
    if (user) {
      // Validate session
      const token = localStorage.getItem('thcpanel_token');
      if (token && validateSession(user.id, token)) {
        setAuthState({
          isAuthenticated: true,
          user,
          token
        });
      } else {
        // Invalid session, clear it
        clearSession(user.id);
        localStorage.removeItem('thcpanel_token');
      }
    }
    setLoading(false);
  }, []);

  const login = useCallback((username: string, password: string): { success: boolean; message: string; pendingApproval?: boolean } => {
    const user = getUserByUsername(username);
    
    if (!user) {
      return { success: false, message: 'Kullanici bulunamadi' };
    }
    
    // Check if account is locked
    if (isAccountLocked(user)) {
      const remaining = Math.ceil((new Date(user.lockedUntil!).getTime() - Date.now()) / 60000);
      return { success: false, message: `Hesabiniz kilitli. ${remaining} dakika sonra tekrar deneyin.` };
    }
    
    if (!user.isActive) {
      return { success: false, message: 'Hesap aktif degil' };
    }
    
    // Check if approved
    if (!user.isApproved) {
      setPendingApproval(true);
      return { success: false, message: 'Hesabiniz onay bekliyor. Lutfen owner ile iletisime gecin.', pendingApproval: true };
    }
    
    if (user.password !== password) {
      const attempts = recordFailedLogin(username);
      const remaining = 5 - attempts;
      return { 
        success: false, 
        message: `Sifre hatali. ${remaining > 0 ? `${remaining} deneme hakkiniz kaldi.` : 'Hesabiniz kilitlendi.'}` 
      };
    }
    
    // Reset failed attempts on successful login
    resetLoginAttempts(user.id);
    
    // Create session
    const token = createSession(user.id);
    localStorage.setItem('thcpanel_token', token);
    
    // Update last login
    updateUser(user.id, { lastLogin: new Date() });
    
    setAuthState({
      isAuthenticated: true,
      user,
      token
    });
    
    addLog({
      id: generateId(),
      userId: user.id,
      username: user.username,
      action: 'LOGIN',
      details: 'User logged in successfully',
      timestamp: new Date()
    });
    
    return { success: true, message: 'Giris basarili' };
  }, []);

  const logout = useCallback(() => {
    if (authState.user) {
      addLog({
        id: generateId(),
        userId: authState.user.id,
        username: authState.user.username,
        action: 'LOGOUT',
        details: 'User logged out',
        timestamp: new Date()
      });
      
      clearSession(authState.user.id);
      localStorage.removeItem('thcpanel_token');
    }
    
    setAuthState({
      isAuthenticated: false,
      user: null,
      token: null
    });
    setPendingApproval(false);
  }, [authState.user]);

  const register = useCallback((username: string, password: string, email: string): { success: boolean; message: string; pendingApproval?: boolean } => {
    if (username.length < 3) {
      return { success: false, message: 'Kullanici adi en az 3 karakter olmali' };
    }
    
    if (password.length < 6) {
      return { success: false, message: 'Sifre en az 6 karakter olmali' };
    }
    
    const result = createUser({
      username,
      password,
      email,
      role: 'user',
      membershipType: 'none',
      isActive: true,
      permissions: ['queries.view', 'queries.free']
    });
    
    if (result.success) {
      setPendingApproval(true);
      return { 
        success: true, 
        message: 'Kayit basarili! Hesabiniz onay icin bekliyor. Telegram @venged7f ile iletisime gecin.',
        pendingApproval: true
      };
    }
    
    return result;
  }, []);

  const refreshUser = useCallback(() => {
    const user = getCurrentUser();
    if (user) {
      setAuthState(prev => ({
        ...prev,
        user
      }));
    }
  }, []);

  return {
    ...authState,
    loading,
    pendingApproval,
    login,
    logout,
    register,
    refreshUser
  };
};
