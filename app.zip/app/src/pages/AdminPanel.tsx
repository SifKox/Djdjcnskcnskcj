import { useState, useEffect } from 'react';
import {
  Shield,
  Users,
  ScrollText,
  Crown,
  Gem,
  Search,
  CheckCircle,
  XCircle,
  Trash2,
  Edit,
  Save,
  X,
  AlertCircle,
  Check,
  Lock,
  Radio,
  Terminal,
  Zap
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import type { User, Log } from '@/types';
import {
  getUsers,
  getLogs,
  updateUser,
  deleteUser,
  addLog,
  generateId,
  canGrantPermissions,
  canViewIpLogs,
  hasPermission,
  getSecurityInfo
} from '@/utils/database';

interface AdminPanelProps {
  user: User | null;
}

const ROLES = [
  { value: 'user', label: 'USER', color: 'bg-slate-600' },
  { value: 'vip', label: 'VIP', color: 'bg-[#ffff00]' },
  { value: 'elmas', label: 'ELMAS', color: 'bg-[#00ffff]' },
  { value: 'moderator', label: 'MOD', color: 'bg-[#0080ff]' },
  { value: 'vendor', label: 'VENDOR', color: 'bg-[#00ff00]' },
  { value: 'admin', label: 'ADMIN', color: 'bg-[#ff00ff]' },
];

const PERMISSIONS = [
  { value: 'queries.view', label: 'Sorgulari Goruntule' },
  { value: 'queries.free', label: 'Ucretsiz Sorgular' },
  { value: 'queries.premium', label: 'Premium Sorgular' },
  { value: 'market.view', label: 'Market Goruntule' },
  { value: 'users.view', label: 'Kullanicilari Goruntule' },
  { value: 'admin.view', label: 'Admin Paneli' },
  { value: 'admin.logs', label: 'Sistem Loglari' },
  { value: 'admin.memberships', label: 'Uyelik Yonetimi' },
];

export default function AdminPanel({ user }: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState('users');
  const [users, setUsers] = useState<User[]>([]);
  const [logs, setLogs] = useState<Log[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [message, setMessage] = useState('');
  const [showIpLogs, setShowIpLogs] = useState(false);

  useEffect(() => {
    loadData();
    setShowIpLogs(canViewIpLogs(user));
  }, [user]);

  const loadData = () => {
    setUsers(getUsers());
    setLogs(getLogs());
  };

  const filteredUsers = users.filter(u =>
    u.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleUpdateUser = () => {
    if (!editingUser) return;

    updateUser(editingUser.id, {
      role: editingUser.role,
      membershipType: editingUser.membershipType,
      isActive: editingUser.isActive,
      permissions: editingUser.permissions
    });

    addLog({
      id: generateId(),
      userId: user?.id || '',
      username: user?.username || '',
      action: 'USER_UPDATED',
      details: `Updated user ${editingUser.username}`,
      timestamp: new Date()
    });

    setMessage('Kullanici guncellendi');
    setShowEditDialog(false);
    setEditingUser(null);
    loadData();

    setTimeout(() => setMessage(''), 3000);
  };

  const handleDeleteUser = (userId: string) => {
    if (!confirm('Bu kullaniciyi silmek istediginize emin misiniz?')) return;

    deleteUser(userId);
    addLog({
      id: generateId(),
      userId: user?.id || '',
      username: user?.username || '',
      action: 'USER_DELETED',
      details: `Deleted user ${userId}`,
      timestamp: new Date()
    });

    setMessage('Kullanici silindi');
    loadData();

    setTimeout(() => setMessage(''), 3000);
  };

  const togglePermission = (permission: string) => {
    if (!editingUser) return;

    const currentPerms = editingUser.permissions || [];
    const newPerms = currentPerms.includes(permission)
      ? currentPerms.filter(p => p !== permission)
      : [...currentPerms, permission];

    setEditingUser({ ...editingUser, permissions: newPerms });
  };

  const getRoleBadge = (role: string) => {
    const roleInfo = ROLES.find(r => r.value === role);
    return (
      <span className={`px-2 py-0.5 rounded text-[10px] font-bold text-black ${roleInfo?.color || 'bg-slate-600'}`}>
        {roleInfo?.label || role}
      </span>
    );
  };

  const security = getSecurityInfo();

  if (!hasPermission(user, 'admin.view')) {
    return (
      <div className="p-8 flex flex-col items-center justify-center min-h-[60vh]">
        <Shield className="w-16 h-16 text-red-500 mb-4" />
        <h2 className="text-2xl font-bold text-white mb-2 font-mono">ERISIM REDDEDILDI</h2>
        <p className="text-slate-400 font-mono">Bu sayfaya erisim izniniz bulunmuyor.</p>
      </div>
    );
  }

  return (
    <div className="p-6 min-h-screen bg-[#020204]">
      {/* Background */}
      <div 
        className="fixed inset-0 opacity-5 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(rgba(0, 255, 255, 0.3) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255, 0, 255, 0.3) 1px, transparent 1px)
          `,
          backgroundSize: '40px 40px'
        }}
      />

      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-2 flex items-center gap-3 font-mono">
          <Shield className="w-8 h-8 text-[#ff00ff]" />
          <span className="text-[#ff00ff]">ADMIN</span>
          <span className="text-[#00ffff]">PANEL</span>
        </h1>
        <p className="text-slate-400 font-mono">
          Sistem yonetimi ve kullanici kontrolu
        </p>
      </div>

      {message && (
        <div className="mb-6 p-4 rounded-xl bg-[#00ff00]/10 border border-[#00ff00]/50 text-[#00ff00] font-mono">
          &gt; {message}
        </div>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="bg-black/50 border border-[#00ffff]/30 mb-6">
          <TabsTrigger value="users" className="data-[state=active]:bg-[#00ffff]/20 data-[state=active]:text-[#00ffff] text-slate-400 font-mono">
            <Users className="w-4 h-4 mr-2" />
            KULLANICILAR
          </TabsTrigger>
          {showIpLogs && (
            <TabsTrigger value="logs" className="data-[state=active]:bg-[#ff00ff]/20 data-[state=active]:text-[#ff00ff] text-slate-400 font-mono">
              <ScrollText className="w-4 h-4 mr-2" />
              LOGLAR
            </TabsTrigger>
          )}
          <TabsTrigger value="memberships" className="data-[state=active]:bg-[#ffff00]/20 data-[state=active]:text-[#ffff00] text-slate-400 font-mono">
            <Crown className="w-4 h-4 mr-2" />
            UYELIKLER
          </TabsTrigger>
          <TabsTrigger value="security" className="data-[state=active]:bg-[#00ff00]/20 data-[state=active]:text-[#00ff00] text-slate-400 font-mono">
            <Lock className="w-4 h-4 mr-2" />
            GUVENLIK
          </TabsTrigger>
        </TabsList>

        {/* Users Tab */}
        <TabsContent value="users">
          <div className="bg-black/80 border border-[#00ffff]/30 rounded-xl p-6 cyber-card">
            <div className="flex items-center gap-4 mb-6">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#00ffff]" />
                <Input
                  type="text"
                  value={searchTerm}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchTerm(e.target.value)}
                  placeholder="Kullanici ara..."
                  className="pl-10 bg-black/50 border-[#00ffff]/50 text-white font-mono"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-[#00ffff]/30">
                    <th className="text-left py-3 px-4 text-[#00ffff] text-xs font-mono">KULLANICI</th>
                    <th className="text-left py-3 px-4 text-[#00ffff] text-xs font-mono">ROL</th>
                    <th className="text-left py-3 px-4 text-[#00ffff] text-xs font-mono">UYELIK</th>
                    <th className="text-left py-3 px-4 text-[#00ffff] text-xs font-mono">DURUM</th>
                    <th className="text-left py-3 px-4 text-[#00ffff] text-xs font-mono">ISLEMLER</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredUsers.map((u) => (
                    <tr key={u.id} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded bg-gradient-to-br from-[#00ffff] to-[#ff00ff] flex items-center justify-center text-black text-sm font-bold">
                            {u.username.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <p className="text-white font-mono text-sm">{u.username}</p>
                            <p className="text-slate-500 text-xs font-mono">{u.email}</p>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4">{getRoleBadge(u.role)}</td>
                      <td className="py-3 px-4">
                        {u.membershipType === 'elmas' ? (
                          <span className="flex items-center gap-1 text-[#00ffff] text-sm font-mono">
                            <Gem className="w-4 h-4" /> ELMAS
                          </span>
                        ) : u.membershipType === 'vip' ? (
                          <span className="flex items-center gap-1 text-[#ffff00] text-sm font-mono">
                            <Crown className="w-4 h-4" /> VIP
                          </span>
                        ) : u.membershipType === 'vendor' ? (
                          <span className="flex items-center gap-1 text-[#00ff00] text-sm font-mono">
                            <Zap className="w-4 h-4" /> VENDOR
                          </span>
                        ) : (
                          <span className="text-slate-500 text-sm font-mono">STANDART</span>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        {u.isActive ? (
                          <span className="flex items-center gap-1 text-[#00ff00] text-sm font-mono">
                            <CheckCircle className="w-4 h-4" /> AKTIF
                          </span>
                        ) : (
                          <span className="flex items-center gap-1 text-red-400 text-sm font-mono">
                            <XCircle className="w-4 h-4" /> PASIF
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => {
                              setEditingUser(u);
                              setShowEditDialog(true);
                            }}
                            className="p-2 rounded-lg hover:bg-[#00ffff]/20 text-[#00ffff] transition-colors"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          {user?.role === 'founder' && u.id !== user?.id && (
                            <button
                              onClick={() => handleDeleteUser(u.id)}
                              className="p-2 rounded-lg hover:bg-red-500/20 text-red-400 transition-colors"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </TabsContent>

        {/* Logs Tab */}
        {showIpLogs && (
          <TabsContent value="logs">
            <div className="bg-black/80 border border-[#ff00ff]/30 rounded-xl p-6 cyber-card">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-[#ff00ff]/30">
                      <th className="text-left py-3 px-4 text-[#ff00ff] text-xs font-mono">TARIH</th>
                      <th className="text-left py-3 px-4 text-[#ff00ff] text-xs font-mono">KULLANICI</th>
                      <th className="text-left py-3 px-4 text-[#ff00ff] text-xs font-mono">ISLEM</th>
                      <th className="text-left py-3 px-4 text-[#ff00ff] text-xs font-mono">DETAY</th>
                    </tr>
                  </thead>
                  <tbody>
                    {logs.slice(0, 50).map((log) => (
                      <tr key={log.id} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                        <td className="py-3 px-4 text-slate-400 text-xs font-mono">
                          {new Date(log.timestamp).toLocaleString('tr-TR')}
                        </td>
                        <td className="py-3 px-4 text-white text-sm font-mono">{log.username}</td>
                        <td className="py-3 px-4">
                          <span className="px-2 py-1 rounded bg-[#00ffff]/20 text-[#00ffff] text-xs font-mono">
                            {log.action}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-slate-400 text-xs font-mono">{log.details}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </TabsContent>
        )}

        {/* Memberships Tab */}
        <TabsContent value="memberships">
          <div className="bg-black/80 border border-[#ffff00]/30 rounded-xl p-6 cyber-card">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {users.filter(u => u.membershipType && u.membershipType !== 'none').map((u) => (
                <div key={u.id} className="p-4 rounded-lg bg-white/5 border border-white/10">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 rounded bg-gradient-to-br from-[#00ffff] to-[#ff00ff] flex items-center justify-center text-black font-bold">
                      {u.username.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <p className="text-white font-mono text-sm">{u.username}</p>
                      <p className="text-slate-500 text-xs font-mono">{u.email}</p>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-400 font-mono">UYELIK:</span>
                      <span className={u.membershipType === 'elmas' ? 'text-[#00ffff] font-mono' : u.membershipType === 'vendor' ? 'text-[#00ff00] font-mono' : 'text-[#ffff00] font-mono'}>
                        {u.membershipType?.toUpperCase()}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-400 font-mono">BITIS:</span>
                      <span className="text-white font-mono">
                        {u.membershipExpiry 
                          ? new Date(u.membershipExpiry).toLocaleDateString('tr-TR')
                          : 'SINIRSIZ'}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </TabsContent>

        {/* Security Tab */}
        <TabsContent value="security">
          <div className="bg-black/80 border border-[#00ff00]/30 rounded-xl p-6 cyber-card">
            <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2 font-mono">
              <Lock className="w-5 h-5 text-[#00ff00]" />
              GUVENLIK_DURUMU
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="p-4 rounded-lg bg-[#00ff00]/10 border border-[#00ff00]/30">
                  <div className="flex items-center gap-3 mb-2">
                    <Lock className="w-6 h-6 text-[#00ff00]" />
                    <span className="text-white font-bold">SIFRELEME</span>
                  </div>
                  <p className="text-[#00ff00] font-mono">{security.encryption}</p>
                  <p className="text-xs text-slate-400 mt-1">Tum veriler sifrelenir</p>
                </div>

                <div className="p-4 rounded-lg bg-[#00ffff]/10 border border-[#00ffff]/30">
                  <div className="flex items-center gap-3 mb-2">
                    <Radio className="w-6 h-6 text-[#00ffff]" />
                    <span className="text-white font-bold">IP MASKING</span>
                  </div>
                  <p className="text-[#00ffff] font-mono">{security.ipMasking}</p>
                  <p className="text-xs text-slate-400 mt-1">Kullanici IP&apos;leri gizlenir</p>
                </div>
              </div>

              <div className="space-y-4">
                <div className="p-4 rounded-lg bg-[#ff00ff]/10 border border-[#ff00ff]/30">
                  <div className="flex items-center gap-3 mb-2">
                    <Terminal className="w-6 h-6 text-[#ff00ff]" />
                    <span className="text-white font-bold">SUNUCU KONUMU</span>
                  </div>
                  <p className="text-[#ff00ff] font-mono">{security.serverLocation}</p>
                  <p className="text-xs text-slate-400 mt-1">Offshore hosting</p>
                </div>

                <div className="p-4 rounded-lg bg-[#ffff00]/10 border border-[#ffff00]/30">
                  <div className="flex items-center gap-3 mb-2">
                    <Shield className="w-6 h-6 text-[#ffff00]" />
                    <span className="text-white font-bold">DDOS KORUMA</span>
                  </div>
                  <p className="text-[#ffff00] font-mono">AKTIF</p>
                  <p className="text-xs text-slate-400 mt-1">7/24 koruma aktif</p>
                </div>
              </div>
            </div>

            <div className="mt-6 p-4 rounded-lg bg-red-500/10 border border-red-500/30">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-red-400 font-bold mb-2">GUVENLIK UYARISI</p>
                  <ul className="text-sm text-red-300 space-y-1">
                    <li>&gt; Backdoor bulunmamaktadir</li>
                    <li>&gt; Tum baglantilar sifrelidir</li>
                    <li>&gt; IP loglari sadece Founder/Admin erisebilir</li>
                    <li>&gt; Vendor kullanicilar IP loglarini goremez</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {/* Edit User Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="bg-[#020204] border border-[#00ffff]/50 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl font-mono text-[#00ffff]">KULLANICI DUZENLE</DialogTitle>
            <DialogDescription className="text-slate-400 font-mono">
              {editingUser?.username} kullanicisinin bilgilerini duzenleyin
            </DialogDescription>
          </DialogHeader>

          {editingUser && (
            <div className="space-y-6 mt-4">
              {/* Role */}
              <div>
                <Label className="text-[#00ffff] mb-2 block font-mono">ROL</Label>
                <Select
                  value={editingUser.role}
                  onValueChange={(value: string) => setEditingUser({ ...editingUser, role: value as User['role'] })}
                >
                  <SelectTrigger className="bg-black/50 border-[#00ffff]/50 text-white font-mono">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[#020204] border-[#00ffff]/50">
                    {ROLES.map((role) => (
                      <SelectItem key={role.value} value={role.value} className="font-mono">
                        {role.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Membership */}
              <div>
                <Label className="text-[#00ffff] mb-2 block font-mono">UYELIK</Label>
                <Select
                  value={editingUser.membershipType || 'none'}
                  onValueChange={(value: string) => setEditingUser({ ...editingUser, membershipType: value as User['membershipType'] })}
                >
                  <SelectTrigger className="bg-black/50 border-[#00ffff]/50 text-white font-mono">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[#020204] border-[#00ffff]/50">
                    <SelectItem value="none" className="font-mono">STANDART</SelectItem>
                    <SelectItem value="vip" className="font-mono">VIP</SelectItem>
                    <SelectItem value="elmas" className="font-mono">ELMAS</SelectItem>
                    <SelectItem value="vendor" className="font-mono">VENDOR</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Status */}
              <div>
                <Label className="text-[#00ffff] mb-2 block font-mono">DURUM</Label>
                <div className="flex items-center gap-4">
                  <button
                    onClick={() => setEditingUser({ ...editingUser, isActive: true })}
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg border transition-colors font-mono ${
                      editingUser.isActive
                        ? 'bg-[#00ff00]/20 border-[#00ff00]/50 text-[#00ff00]'
                        : 'border-white/10 text-slate-400 hover:bg-white/5'
                    }`}
                  >
                    <CheckCircle className="w-4 h-4" />
                    AKTIF
                  </button>
                  <button
                    onClick={() => setEditingUser({ ...editingUser, isActive: false })}
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg border transition-colors font-mono ${
                      !editingUser.isActive
                        ? 'bg-red-500/20 border-red-500/50 text-red-400'
                        : 'border-white/10 text-slate-400 hover:bg-white/5'
                    }`}
                  >
                    <XCircle className="w-4 h-4" />
                    PASIF
                  </button>
                </div>
              </div>

              {/* Permissions */}
              {canGrantPermissions(user) && (
                <div>
                  <Label className="text-[#00ffff] mb-2 block font-mono">IZINLER</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {PERMISSIONS.map((perm) => (
                      <button
                        key={perm.value}
                        onClick={() => togglePermission(perm.value)}
                        className={`flex items-center gap-2 p-2 rounded-lg border transition-colors text-left font-mono text-sm ${
                          editingUser.permissions?.includes(perm.value)
                            ? 'bg-[#00ffff]/20 border-[#00ffff]/50 text-[#00ffff]'
                            : 'border-white/10 text-slate-400 hover:bg-white/5'
                        }`}
                      >
                        {editingUser.permissions?.includes(perm.value) ? (
                          <Check className="w-4 h-4" />
                        ) : (
                          <div className="w-4 h-4 rounded border border-current" />
                        )}
                        {perm.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {!canGrantPermissions(user) && (
                <div className="flex items-start gap-2 p-3 rounded-lg bg-[#ffff00]/10 border border-[#ffff00]/30">
                  <AlertCircle className="w-5 h-5 text-[#ffff00] flex-shrink-0 mt-0.5" />
                  <p className="text-[#ffff00] text-sm font-mono">
                    Yetki verme islemlerini sadece Admin ve Founder yapabilir.
                  </p>
                </div>
              )}

              {/* Actions */}
              <div className="flex gap-3 pt-4">
                <Button
                  variant="outline"
                  onClick={() => setShowEditDialog(false)}
                  className="flex-1 border-[#ff00ff]/50 text-[#ff00ff] hover:bg-[#ff00ff]/10"
                >
                  <X className="w-4 h-4 mr-2" />
                  IPTAL
                </Button>
                <Button
                  onClick={handleUpdateUser}
                  className="flex-1 bg-[#00ff00] text-black hover:bg-[#00ff00]/80 font-bold"
                >
                  <Save className="w-4 h-4 mr-2" />
                  KAYDET
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
