import { useEffect, useState } from 'react';
import {
  Search,
  Users,
  Activity,
  Zap,
  Crown,
  Clock,
  Shield,
  Lock,
  Radio,
  Terminal,
  Bitcoin,
  MessageCircle
} from 'lucide-react';
import type { User } from '@/types';
import { getLogs, getQueries, getUsers, TELEGRAM_CONTACT, BITCOIN_WALLET } from '@/utils/database';

interface DashboardProps {
  user: User | null;
}

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ElementType;
  color: string;
  glowColor: string;
}

function StatCard({ title, value, icon: Icon, color, glowColor }: StatCardProps) {
  return (
    <div className="relative group">
      <div 
        className="absolute -inset-0.5 rounded-lg blur opacity-30 group-hover:opacity-60 transition-opacity"
        style={{ background: glowColor }}
      />
      <div className="relative bg-black/80 border border-[#00ffff]/30 rounded-lg p-5 cyber-card">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-slate-500 text-xs font-mono mb-1">{title}</p>
            <p className="text-2xl font-bold text-white font-mono">{value}</p>
          </div>
          <div 
            className="w-12 h-12 rounded-lg flex items-center justify-center"
            style={{ background: `linear-gradient(135deg, ${color}, transparent)` }}
          >
            <Icon className="w-6 h-6 text-white" />
          </div>
        </div>
      </div>
    </div>
  );
}

export default function Dashboard({ user }: DashboardProps) {
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalQueries: 0,
    todayQueries: 0,
    activeUsers: 0
  });
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const users = getUsers();
    const queries = getQueries();
    const today = new Date().toDateString();
    const todayQueries = queries.filter(q => new Date(q.timestamp).toDateString() === today).length;

    setStats({
      totalUsers: users.length,
      totalQueries: queries.length,
      todayQueries,
      activeUsers: users.filter(u => u.isActive).length
    });

    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'founder': return 'from-[#ff0040] to-[#ff4000]';
      case 'admin': return 'from-[#ff00ff] to-[#ff40ff]';
      case 'vendor': return 'from-[#00ff00] to-[#40ff40]';
      case 'elmas': return 'from-[#00ffff] to-[#40ffff]';
      case 'vip': return 'from-[#ffff00] to-[#ffff40]';
      default: return 'from-slate-600 to-slate-500';
    }
  };

  return (
    <div className="p-6 space-y-6 bg-[#020204] min-h-screen">
      {/* Background Effects */}
      <div 
        className="fixed inset-0 opacity-5 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(rgba(0, 255, 255, 0.3) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255, 0, 255, 0.3) 1px, transparent 1px)
          `,
          backgroundSize: '40px 40px'
        }}
      />

      {/* Header */}
      <div className="relative overflow-hidden rounded-xl bg-gradient-to-br from-[#00ffff]/10 via-black/80 to-[#ff00ff]/10 border border-[#00ffff]/30 p-6">
        <div className="absolute top-0 right-0 w-64 h-64 bg-[#00ffff]/10 rounded-full blur-[100px]" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-[#ff00ff]/10 rounded-full blur-[100px]" />
        
        <div className="relative z-10">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <span className="px-3 py-1 rounded bg-[#00ffff]/20 border border-[#00ffff]/50 text-[#00ffff] text-xs font-mono">
                &gt; SYSTEM_READY
              </span>
              {user?.membershipType && user.membershipType !== 'none' && (
                <span className={`px-3 py-1 rounded bg-gradient-to-r ${getRoleColor(user.membershipType)} text-black text-xs font-bold`}>
                  {user.membershipType.toUpperCase()}
                </span>
              )}
            </div>
            <span className="text-[#00ffff] font-mono text-sm">
              {currentTime.toLocaleString('tr-TR')}
            </span>
          </div>

          <h1 className="text-3xl font-bold text-white mb-2 font-mono">
            <span className="text-[#00ffff]">WELCOME,</span>{' '}
            <span className="text-[#ff00ff]">{user?.username.toUpperCase()}</span>
          </h1>
          
          <p className="text-slate-400 max-w-xl font-mono text-sm">
            THCpanel&apos;e hoş geldiniz. Tüm sorgularınız şifrelenmiş ve anonim olarak işlenmektedir.
          </p>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="TOPLAM_USER"
          value={stats.totalUsers}
          icon={Users}
          color="#0080ff"
          glowColor="linear-gradient(135deg, #0080ff, transparent)"
        />
        <StatCard
          title="TOPLAM_SORGU"
          value={stats.totalQueries}
          icon={Search}
          color="#00ffff"
          glowColor="linear-gradient(135deg, #00ffff, transparent)"
        />
        <StatCard
          title="BUGUN_SORGU"
          value={stats.todayQueries}
          icon={Activity}
          color="#00ff00"
          glowColor="linear-gradient(135deg, #00ff00, transparent)"
        />
        <StatCard
          title="AKTIF_USER"
          value={stats.activeUsers}
          icon={Zap}
          color="#ffff00"
          glowColor="linear-gradient(135deg, #ffff00, transparent)"
        />
      </div>

      {/* Two Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Quick Access */}
        <div className="bg-black/80 border border-[#00ffff]/30 rounded-xl p-6 cyber-card">
          <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2 font-mono">
            <Terminal className="w-5 h-5 text-[#00ffff]" />
            HIZLI_ERISIM
          </h3>
          
          <div className="grid grid-cols-2 gap-3">
            {[
              { id: 'free-queries', label: 'ÜCRETSIZ SORGULAR', color: '#00ff00', desc: 'TC, GSM, Adres' },
              { id: 'premium-queries', label: 'PREMIUM SORGULAR', color: '#ff00ff', desc: 'Plaka, IP, E-posta' },
              { id: 'market', label: 'UYELIK AL', color: '#00ffff', desc: 'VIP / Elmas / Vendor' },
              { id: 'users', label: 'TOPLULUK', color: '#ffff00', desc: 'Tüm kullanıcılar' },
            ].map((item) => (
              <button
                key={item.id}
                className="p-4 rounded-lg border transition-all duration-300 text-left group hover:scale-[1.02]"
                style={{ 
                  borderColor: `${item.color}40`,
                  background: `linear-gradient(135deg, ${item.color}10, transparent)`
                }}
              >
                <p className="font-bold text-sm mb-1" style={{ color: item.color }}>{item.label}</p>
                <p className="text-xs text-slate-500">{item.desc}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Contact & Payment */}
        <div className="bg-black/80 border border-[#00ffff]/30 rounded-xl p-6 cyber-card">
          <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2 font-mono">
            <MessageCircle className="w-5 h-5 text-[#ff00ff]" />
            ILETISIM_ODEME
          </h3>
          
          <div className="space-y-4">
            {/* Telegram */}
            <div className="p-4 rounded-lg bg-[#0088cc]/10 border border-[#0088cc]/30">
              <div className="flex items-center gap-3 mb-2">
                <MessageCircle className="w-5 h-5 text-[#0088cc]" />
                <span className="text-white font-bold">Telegram Destek</span>
              </div>
              <p className="text-sm text-slate-400 mb-2">Ödeme öncesi mutlaka iletişime geçin</p>
              <div className="flex items-center gap-2">
                <span className="text-[#0088cc] font-mono text-sm">@</span>
                <span className="text-white font-mono">{TELEGRAM_CONTACT}</span>
              </div>
            </div>

            {/* Bitcoin */}
            <div className="p-4 rounded-lg bg-[#f7931a]/10 border border-[#f7931a]/30">
              <div className="flex items-center gap-3 mb-2">
                <Bitcoin className="w-5 h-5 text-[#f7931a]" />
                <span className="text-white font-bold">Bitcoin Cüzdan</span>
              </div>
              <p className="text-sm text-slate-400 mb-2">Sadece BTC kabul edilir</p>
              <div className="p-2 bg-black/50 rounded font-mono text-xs text-[#f7931a] break-all">
                {BITCOIN_WALLET}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Membership Info */}
      <div className="bg-black/80 border border-[#00ffff]/30 rounded-xl p-6 cyber-card">
        <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2 font-mono">
          <Crown className="w-5 h-5 text-[#ffff00]" />
          UYELIK_BILGILERI
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 rounded-lg bg-gradient-to-br from-[#00ffff]/10 to-transparent border border-[#00ffff]/30">
            <p className="text-slate-500 text-xs font-mono mb-1">MEVCUT_UYELIK</p>
            <p className={`text-xl font-bold font-mono ${user?.membershipType === 'none' || !user?.membershipType ? 'text-slate-400' : 'text-[#00ffff]'}`}>
              {user?.membershipType === 'none' || !user?.membershipType ? 'STANDART' : user.membershipType.toUpperCase()}
            </p>
          </div>
          
          <div className="p-4 rounded-lg bg-gradient-to-br from-[#ff00ff]/10 to-transparent border border-[#ff00ff]/30">
            <p className="text-slate-500 text-xs font-mono mb-1">KALAN_SURE</p>
            <p className="text-xl font-bold text-[#ff00ff] font-mono">
              {user?.membershipExpiry 
                ? `${Math.max(0, Math.ceil((new Date(user.membershipExpiry).getTime() - Date.now()) / (1000 * 60 * 60 * 24)))} GUN`
                : 'SINIRSIZ'}
            </p>
          </div>
          
          <div className="p-4 rounded-lg bg-gradient-to-br from-[#00ff00]/10 to-transparent border border-[#00ff00]/30">
            <p className="text-slate-500 text-xs font-mono mb-1">SORGU_LIMITI</p>
            <p className="text-xl font-bold text-[#00ff00] font-mono">SINIRSIZ</p>
          </div>
        </div>
      </div>

      {/* Security Status */}
      <div className="bg-black/80 border border-[#00ff00]/30 rounded-xl p-6 cyber-card">
        <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2 font-mono">
          <Shield className="w-5 h-5 text-[#00ff00]" />
          GUVENLIK_DURUMU
        </h3>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { icon: Lock, label: 'SIFRELEME', value: 'AES-256', color: '#00ff00' },
            { icon: Radio, label: 'IP_MASKING', value: 'AKTIF', color: '#00ffff' },
            { icon: Terminal, label: 'SUNUCU', value: 'OFFSHORE', color: '#ff00ff' },
            { icon: Shield, label: 'DDOS_KORUMA', value: 'AKTIF', color: '#ffff00' },
          ].map((item, i) => (
            <div key={i} className="flex items-center gap-3 p-3 rounded-lg bg-white/5">
              <item.icon className="w-5 h-5" style={{ color: item.color }} />
              <div>
                <p className="text-[10px] text-slate-500 font-mono">{item.label}</p>
                <p className="text-sm font-bold font-mono" style={{ color: item.color }}>{item.value}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-black/80 border border-[#00ffff]/30 rounded-xl p-6 cyber-card">
        <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2 font-mono">
          <Clock className="w-5 h-5 text-[#00ffff]" />
          SON_AKTIVITELER
        </h3>
        
        <div className="space-y-2">
          {getLogs().slice(0, 5).map((log) => (
            <div key={log.id} className="flex items-center gap-4 p-3 rounded-lg bg-white/5 hover:bg-white/10 transition-colors font-mono text-sm">
              <div className="w-2 h-2 rounded-full bg-[#00ffff]" />
              <div className="flex-1">
                <span className="text-[#00ffff]">&gt; {log.action}</span>
                <span className="text-slate-500 ml-2">{log.details}</span>
              </div>
              <span className="text-slate-600 text-xs">
                {new Date(log.timestamp).toLocaleTimeString('tr-TR')}
              </span>
            </div>
          ))}
          {getLogs().length === 0 && (
            <p className="text-slate-500 text-center py-4 font-mono">&gt; NO_DATA_FOUND</p>
          )}
        </div>
      </div>
    </div>
  );
}
