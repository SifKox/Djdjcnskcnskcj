// ============================================
// THCpanel - Login Page
// ============================================

import { useState, useEffect } from 'react';
import { Eye, EyeOff, Shield, Zap, Lock, Terminal, Radio, Cpu, MessageCircle, CheckCircle, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TELEGRAM_CONTACT, getSecurityInfo } from '@/utils/database';

interface LoginProps {
  onLogin: (username: string, password: string) => { success: boolean; message: string; pendingApproval?: boolean };
  onRegister: (username: string, password: string, email: string) => { success: boolean; message: string; pendingApproval?: boolean };
}

// Matrix Rain Component
const MatrixRain = () => {
  const [columns, setColumns] = useState<string[]>([]);
  
  useEffect(() => {
    const chars = '01アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン';
    const cols = Array.from({ length: 30 }, () => 
      Array.from({ length: 20 }, () => chars[Math.floor(Math.random() * chars.length)]).join('')
    );
    setColumns(cols);
  }, []);
  
  return (
    <div className="absolute inset-0 overflow-hidden opacity-10 pointer-events-none">
      {columns.map((col, i) => (
        <div
          key={i}
          className="absolute text-[10px] text-[#00ff00] font-mono whitespace-pre"
          style={{
            left: `${(i / 30) * 100}%`,
            animation: `matrix-fall ${10 + Math.random() * 10}s linear infinite`,
            animationDelay: `${Math.random() * 5}s`
          }}
        >
          {col.split('').map((char, j) => (
            <div key={j} style={{ opacity: 1 - (j / 20) }}>{char}</div>
          ))}
        </div>
      ))}
    </div>
  );
};

// Floating Particles
const Particles = () => {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {Array.from({ length: 50 }).map((_, i) => (
        <div
          key={i}
          className="absolute w-1 h-1 bg-[#00ffff] rounded-full"
          style={{
            left: `${Math.random() * 100}%`,
            animation: `float-particle ${10 + Math.random() * 20}s linear infinite`,
            animationDelay: `${Math.random() * 10}s`,
            opacity: Math.random() * 0.5
          }}
        />
      ))}
    </div>
  );
};

export default function Login({ onLogin, onRegister }: LoginProps) {
  const [showPassword, setShowPassword] = useState(false);
  const [activeTab, setActiveTab] = useState('login');
  const [loginUsername, setLoginUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [loginPending, setLoginPending] = useState(false);
  const [regUsername, setRegUsername] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regError, setRegError] = useState('');
  const [regSuccess, setRegSuccess] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    setLoginPending(false);
    
    const result = onLogin(loginUsername, loginPassword);
    
    if (!result.success) {
      setLoginError(result.message);
      if (result.pendingApproval) {
        setLoginPending(true);
      }
    }
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setRegError('');
    setRegSuccess(false);
    
    const result = onRegister(regUsername, regPassword, regEmail);
    
    if (!result.success) {
      setRegError(result.message);
    } else {
      setRegSuccess(true);
    }
  };

  const security = getSecurityInfo();

  return (
    <div className="min-h-screen w-full flex items-center justify-center relative overflow-hidden bg-[#020204]">
      {/* Background Effects */}
      <MatrixRain />
      <Particles />
      
      {/* Cyber Grid */}
      <div 
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage: `
            linear-gradient(rgba(0, 255, 255, 0.1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255, 0, 255, 0.1) 1px, transparent 1px)
          `,
          backgroundSize: '50px 50px'
        }}
      />

      {/* Glowing Orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#00ffff]/10 rounded-full blur-[150px] animate-pulse" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#ff00ff]/10 rounded-full blur-[150px] animate-pulse delay-1000" />

      {/* Main Container */}
      <div className="relative z-10 w-full max-w-5xl mx-4 flex gap-8 items-center">
        
        {/* Left Side - Branding */}
        <div className="hidden lg:block flex-1">
          <div className="relative">
            {/* Logo */}
            <div className="flex items-center gap-4 mb-6">
              <div className="relative">
                <div className="absolute -inset-4 bg-gradient-to-r from-[#00ffff] to-[#ff00ff] rounded-xl blur-xl opacity-50 animate-pulse" />
                <div className="relative w-20 h-20 bg-gradient-to-br from-[#00ffff] to-[#ff00ff] rounded-xl flex items-center justify-center">
                  <Shield className="w-10 h-10 text-black" />
                </div>
              </div>
              <div>
                <h1 className="text-5xl font-bold text-white glitch" data-text="THCpanel">
                  <span className="text-[#00ffff]">THC</span><span className="text-[#ff00ff]">panel</span>
                </h1>
                <p className="text-[#00ffff] font-mono text-sm tracking-widest">PREMIUM INTELLIGENCE v2.0</p>
              </div>
            </div>

            {/* Description */}
            <p className="text-slate-400 mb-8 text-lg leading-relaxed">
              Turkiye&apos;nin en gelismis sorgu platformu. 
              <span className="text-[#00ffff]"> Anonim</span>, 
              <span className="text-[#ff00ff]"> guvenli</span> ve 
              <span className="text-[#ffff00]"> hizli</span> veri erisimi.
            </p>

            {/* Features */}
            <div className="space-y-4 mb-8">
              {[
                { icon: Lock, text: '256-Bit Sifreleme', color: '#00ffff' },
                { icon: Radio, text: 'IP Masking Aktif', color: '#ff00ff' },
                { icon: Cpu, text: 'DDoS Korumasi', color: '#00ff00' },
                { icon: Terminal, text: 'Offshore Sunucular', color: '#ffff00' },
              ].map((feature, i) => (
                <div key={i} className="flex items-center gap-3">
                  <feature.icon className="w-5 h-5" style={{ color: feature.color }} />
                  <span className="text-slate-300">{feature.text}</span>
                </div>
              ))}
            </div>

            {/* Contact */}
            <div className="p-4 bg-gradient-to-r from-[#00ffff]/10 to-[#ff00ff]/10 border border-[#00ffff]/30 rounded-lg">
              <p className="text-sm text-slate-400 mb-2">Odeme ve destek icin:</p>
              <div className="flex items-center gap-2">
                <span className="text-[#00ffff] font-mono">Telegram:</span>
                <span className="text-white font-bold">@{TELEGRAM_CONTACT}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side - Form */}
        <div className="w-full max-w-md">
          {/* Status Bar */}
          <div className="flex items-center justify-between mb-4 px-2">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-[#00ff00] rounded-full animate-pulse" />
              <span className="text-xs text-[#00ff00] font-mono">SYSTEM ONLINE</span>
            </div>
            <span className="text-xs text-slate-500 font-mono">
              {currentTime.toLocaleTimeString('tr-TR')}
            </span>
          </div>

          {/* Form Card */}
          <div className="relative">
            <div className="absolute -inset-1 bg-gradient-to-r from-[#00ffff] to-[#ff00ff] rounded-lg blur opacity-30" />
            
            <div className="relative cyber-card p-8">
              {/* Corner Decorations */}
              <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-[#00ffff]" />
              <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-[#ff00ff]" />
              <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-[#ff00ff]" />
              <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-[#00ffff]" />

              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-2 bg-black/50 border border-[#00ffff]/30 mb-6">
                  <TabsTrigger 
                    value="login" 
                    className="data-[state=active]:bg-[#00ffff]/20 data-[state=active]:text-[#00ffff] text-slate-400 font-mono"
                  >
                    [ GIRIS ]
                  </TabsTrigger>
                  <TabsTrigger 
                    value="register"
                    className="data-[state=active]:bg-[#ff00ff]/20 data-[state=active]:text-[#ff00ff] text-slate-400 font-mono"
                  >
                    [ KAYIT ]
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="login">
                  <form onSubmit={handleLogin} className="space-y-4">
                    <div>
                      <Label className="text-[#00ffff] text-xs font-mono mb-1 block">KULLANICI_ADI</Label>
                      <div className="relative">
                        <Terminal className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#00ffff]" />
                        <Input
                          type="text"
                          value={loginUsername}
                          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setLoginUsername(e.target.value)}
                          placeholder="root"
                          className="pl-10 bg-black/50 border-[#00ffff]/50 text-white placeholder:text-slate-600 focus:border-[#00ffff] focus:ring-[#00ffff]/20 font-mono"
                        />
                      </div>
                    </div>

                    <div>
                      <Label className="text-[#00ffff] text-xs font-mono mb-1 block">SIFRE</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#00ffff]" />
                        <Input
                          type={showPassword ? 'text' : 'password'}
                          value={loginPassword}
                          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setLoginPassword(e.target.value)}
                          placeholder="••••••••"
                          className="pl-10 pr-10 bg-black/50 border-[#00ffff]/50 text-white placeholder:text-slate-600 focus:border-[#00ffff] focus:ring-[#00ffff]/20 font-mono"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-[#00ffff]/50 hover:text-[#00ffff]"
                        >
                          {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>

                    {/* Pending Approval Alert */}
                    {loginPending && (
                      <div className="p-4 bg-[#ffff00]/10 border border-[#ffff00]/50 rounded-lg">
                        <div className="flex items-start gap-3">
                          <Clock className="w-5 h-5 text-[#ffff00] flex-shrink-0 mt-0.5" />
                          <div>
                            <p className="text-[#ffff00] font-bold mb-1">ONAY BEKLIYOR</p>
                            <p className="text-sm text-slate-400 mb-2">
                              Hesabiniz owner onayi icin bekliyor.
                            </p>
                            <a 
                              href={`https://t.me/${TELEGRAM_CONTACT}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-2 px-3 py-1 bg-[#0088cc] text-white rounded text-sm hover:bg-[#0088cc]/80"
                            >
                              <MessageCircle className="w-4 h-4" />
                              Telegram&apos;dan Ulas
                            </a>
                          </div>
                        </div>
                      </div>
                    )}

                    {loginError && !loginPending && (
                      <div className="p-3 bg-red-500/10 border border-red-500/50 text-red-400 text-sm font-mono">
                        &gt; ERROR: {loginError}
                      </div>
                    )}

                    <Button
                      type="submit"
                      className="w-full cyber-btn py-3"
                    >
                      <Zap className="w-4 h-4 mr-2" />
                      BAGLAN
                    </Button>
                  </form>
                </TabsContent>

                <TabsContent value="register">
                  <form onSubmit={handleRegister} className="space-y-4">
                    <div>
                      <Label className="text-[#ff00ff] text-xs font-mono mb-1 block">YENI_KULLANICI</Label>
                      <div className="relative">
                        <Terminal className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#ff00ff]" />
                        <Input
                          type="text"
                          value={regUsername}
                          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setRegUsername(e.target.value)}
                          placeholder="username"
                          className="pl-10 bg-black/50 border-[#ff00ff]/50 text-white placeholder:text-slate-600 focus:border-[#ff00ff] focus:ring-[#ff00ff]/20 font-mono"
                        />
                      </div>
                    </div>

                    <div>
                      <Label className="text-[#ff00ff] text-xs font-mono mb-1 block">E_POSTA</Label>
                      <div className="relative">
                        <Terminal className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#ff00ff]" />
                        <Input
                          type="email"
                          value={regEmail}
                          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setRegEmail(e.target.value)}
                          placeholder="user@proton.me"
                          className="pl-10 bg-black/50 border-[#ff00ff]/50 text-white placeholder:text-slate-600 focus:border-[#ff00ff] focus:ring-[#ff00ff]/20 font-mono"
                        />
                      </div>
                    </div>

                    <div>
                      <Label className="text-[#ff00ff] text-xs font-mono mb-1 block">SIFRE_OLUSTUR</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#ff00ff]" />
                        <Input
                          type={showPassword ? 'text' : 'password'}
                          value={regPassword}
                          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setRegPassword(e.target.value)}
                          placeholder="••••••••"
                          className="pl-10 pr-10 bg-black/50 border-[#ff00ff]/50 text-white placeholder:text-slate-600 focus:border-[#ff00ff] focus:ring-[#ff00ff]/20 font-mono"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-[#ff00ff]/50 hover:text-[#ff00ff]"
                        >
                          {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>

                    {/* Registration Success */}
                    {regSuccess && (
                      <div className="p-4 bg-[#00ff00]/10 border border-[#00ff00]/50 rounded-lg">
                        <div className="flex items-start gap-3">
                          <CheckCircle className="w-5 h-5 text-[#00ff00] flex-shrink-0 mt-0.5" />
                          <div>
                            <p className="text-[#00ff00] font-bold mb-1">KAYIT BASARILI</p>
                            <p className="text-sm text-slate-400 mb-2">
                              Hesabiniz olusturuldu! Owner onayi icin bekliyor.
                            </p>
                            <a 
                              href={`https://t.me/${TELEGRAM_CONTACT}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-2 px-3 py-1 bg-[#0088cc] text-white rounded text-sm hover:bg-[#0088cc]/80"
                            >
                              <MessageCircle className="w-4 h-4" />
                              @{TELEGRAM_CONTACT}
                            </a>
                          </div>
                        </div>
                      </div>
                    )}

                    {regError && (
                      <div className="p-3 bg-red-500/10 border border-red-500/50 text-red-400 text-sm font-mono">
                        &gt; ERROR: {regError}
                      </div>
                    )}

                    <Button
                      type="submit"
                      disabled={regSuccess}
                      className="w-full cyber-btn py-3 border-[#ff00ff] text-[#ff00ff] hover:bg-[#ff00ff]/20 disabled:opacity-50"
                    >
                      <Zap className="w-4 h-4 mr-2" />
                      HESAP OLUSTUR
                    </Button>
                  </form>
                </TabsContent>
              </Tabs>

              {/* Security Footer */}
              <div className="mt-6 pt-4 border-t border-[#00ffff]/20">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-[#00ff00]">ENC: {security.encryption}</span>
                  <span className="text-[#00ffff]">STATUS: {security.status}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
