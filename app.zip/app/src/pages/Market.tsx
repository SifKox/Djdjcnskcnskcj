import { useState } from 'react';
import {
  CreditCard,
  Check,
  Crown,
  Gem,
  Zap,
  Shield,
  Clock,
  AlertCircle,
  Bitcoin,
  MessageCircle,
  Copy
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import type { User } from '@/types';
import { membershipPlans, updateUser, addLog, generateId, BITCOIN_WALLET, TELEGRAM_CONTACT } from '@/utils/database';

interface MarketProps {
  user: User | null;
  onUserUpdate: () => void;
}

export default function Market({ user, onUserUpdate }: MarketProps) {
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [showDialog, setShowDialog] = useState(false);
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [message, setMessage] = useState('');
  const [btcPrice, setBtcPrice] = useState(0);

  // Mock BTC price - in real app, fetch from API
  const getBtcAmount = (tryAmount: number) => {
    // Mock: 1 BTC = 2,000,000 TRY
    return (tryAmount / 2000000).toFixed(8);
  };

  const handlePurchase = () => {
    if (!selectedPlan || !user) return;
    
    const plan = membershipPlans.find(p => p.id === selectedPlan);
    if (!plan) return;

    setBtcPrice(parseFloat(getBtcAmount(plan.price)));
    setShowDialog(false);
    setShowPaymentDialog(true);
  };

  const copyWallet = () => {
    navigator.clipboard.writeText(BITCOIN_WALLET);
    setMessage('Cüzdan adresi kopyalandı!');
    setTimeout(() => setMessage(''), 3000);
  };

  const confirmPayment = () => {
    if (!selectedPlan || !user) return;

    const plan = membershipPlans.find(p => p.id === selectedPlan);
    if (!plan) return;

    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + plan.duration);

    const membershipType = plan.id === 'vendor' ? 'vendor' : 
                          plan.id === 'yearly' || plan.id === 'monthly' ? 'elmas' : 'vip';

    const role = plan.id === 'vendor' ? 'vendor' : 
                 plan.id === 'yearly' || plan.id === 'monthly' ? 'elmas' : 'vip';

    updateUser(user.id, {
      membershipType: membershipType as 'vip' | 'elmas' | 'vendor',
      role: role as User['role'],
      membershipExpiry: expiryDate
    });

    addLog({
      id: generateId(),
      userId: user.id,
      username: user.username,
      action: 'MEMBERSHIP_PURCHASED',
      details: `Purchased ${plan.name} via Bitcoin`,
      timestamp: new Date()
    });

    setMessage('Ödemeniz onaylandı! Üyeliğiniz aktif edildi.');
    setShowPaymentDialog(false);
    onUserUpdate();

    setTimeout(() => setMessage(''), 5000);
  };

  const getPlanIcon = (planId: string) => {
    switch (planId) {
      case 'weekly': return Clock;
      case 'monthly': return Gem;
      case 'yearly': return Crown;
      case 'vendor': return Zap;
      default: return Shield;
    }
  };

  return (
    <div className="p-6 min-h-screen bg-[#020204]">
      {/* Background */}
      <div 
        className="fixed inset-0 opacity-5 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(rgba(0, 255, 255, 0.3) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255, 0, 255, 0.3) 1px, transparent 1px)
          `,
          backgroundSize: '40px 40px'
        }}
      />

      {/* Header */}
      <div className="text-center mb-12 relative">
        <h1 className="text-4xl font-bold text-white mb-4 flex items-center justify-center gap-3 font-mono">
          <CreditCard className="w-10 h-10 text-[#00ffff]" />
          <span className="text-[#00ffff]">UYELIK</span>
          <span className="text-[#ff00ff]">PAKETLERI</span>
        </h1>
        <p className="text-slate-400 max-w-2xl mx-auto font-mono">
          Bitcoin ile ödeme yapın. Ödeme öncesi Telegram üzerinden onay alın.
        </p>
        
        {/* Contact Banner */}
        <div className="mt-6 inline-flex items-center gap-4 p-4 bg-[#0088cc]/10 border border-[#0088cc]/30 rounded-lg">
          <MessageCircle className="w-6 h-6 text-[#0088cc]" />
          <div className="text-left">
            <p className="text-sm text-slate-400">Ödeme için önce iletişime geçin:</p>
            <p className="text-[#0088cc] font-bold font-mono">@{TELEGRAM_CONTACT}</p>
          </div>
        </div>
      </div>

      {message && (
        <div className="mb-6 p-4 rounded-xl bg-[#00ff00]/10 border border-[#00ff00]/50 text-[#00ff00] text-center font-mono">
          &gt; {message}
        </div>
      )}

      {/* Plans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
        {membershipPlans.map((plan) => {
          const Icon = getPlanIcon(plan.id);
          const isCurrentPlan = user?.membershipType === (plan.id === 'vendor' ? 'vendor' : plan.id === 'yearly' || plan.id === 'monthly' ? 'elmas' : 'vip');
          const btcAmount = getBtcAmount(plan.price);

          return (
            <div
              key={plan.id}
              className={`relative group ${isCurrentPlan ? 'ring-2 ring-[#00ff00]' : ''}`}
            >
              <div
                className="absolute -inset-0.5 rounded-xl blur opacity-30 group-hover:opacity-60 transition-opacity"
                style={{ background: plan.color }}
              />
              
              <div className="relative bg-black/90 border rounded-xl p-6 h-full flex flex-col"
                style={{ borderColor: `${plan.color}50` }}
              >
                {isCurrentPlan && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-[#00ff00] text-black text-xs font-bold">
                    AKTIF UYELIK
                  </div>
                )}

                {/* Plan Header */}
                <div className="text-center mb-6">
                  <div
                    className="w-16 h-16 rounded-xl mx-auto mb-4 flex items-center justify-center"
                    style={{ background: `linear-gradient(135deg, ${plan.color}, transparent)` }}
                  >
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-white font-mono" style={{ color: plan.color }}>
                    {plan.name}
                  </h3>
                  <div className="mt-2">
                    <span className="text-3xl font-bold text-white">{plan.price.toLocaleString()}</span>
                    <span className="text-slate-400 ml-1">TRY</span>
                  </div>
                  <div className="mt-1 text-sm text-[#f7931a] font-mono">
                    ≈ {btcAmount} BTC
                  </div>
                </div>

                {/* Features */}
                <div className="flex-1 space-y-3 mb-6">
                  {plan.features.map((feature, index) => (
                    <div key={index} className="flex items-center gap-3">
                      <div
                        className="w-5 h-5 rounded flex items-center justify-center"
                        style={{ background: `${plan.color}30` }}
                      >
                        <Check className="w-3 h-3" style={{ color: plan.color }} />
                      </div>
                      <span className="text-slate-300 text-sm">{feature}</span>
                    </div>
                  ))}
                </div>

                {/* Warning for Vendor */}
                {plan.id === 'vendor' && (
                  <div className="mb-4 p-3 bg-[#ffff00]/10 border border-[#ffff00]/30 rounded text-xs text-[#ffff00]">
                    <strong>NOT:</strong> Vendor üyeler üyelik satabilir ancak IP loglarına erişemez!
                  </div>
                )}

                {/* Button */}
                <Button
                  onClick={() => {
                    setSelectedPlan(plan.id);
                    setShowDialog(true);
                  }}
                  disabled={isCurrentPlan}
                  className="w-full font-bold transition-all duration-300 font-mono"
                  style={{
                    background: isCurrentPlan ? '#334155' : `linear-gradient(135deg, ${plan.color}, ${plan.color}dd)`,
                    color: isCurrentPlan ? '#64748b' : '#000',
                  }}
                >
                  {isCurrentPlan ? 'MEVCUT PLAN' : 'SATIN AL'}
                </Button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Bitcoin Info */}
      <div className="mt-12 max-w-3xl mx-auto">
        <div className="bg-black/80 border border-[#f7931a]/30 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <Bitcoin className="w-8 h-8 text-[#f7931a]" />
            <h3 className="text-xl font-bold text-white font-mono">BITCOIN ODEME</h3>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center gap-2 p-3 bg-[#f7931a]/10 rounded-lg">
              <AlertCircle className="w-5 h-5 text-[#f7931a] flex-shrink-0" />
              <p className="text-sm text-[#f7931a]">
                Sadece Bitcoin (BTC) kabul edilir. Ödeme öncesi Telegram üzerinden onay alın.
              </p>
            </div>
            
            <div className="p-4 bg-black/50 rounded-lg">
              <p className="text-xs text-slate-500 mb-2 font-mono">ODEME ADRESI:</p>
              <div className="flex items-center gap-2">
                <code className="flex-1 text-[#f7931a] font-mono text-sm break-all">
                  {BITCOIN_WALLET}
                </code>
                <button
                  onClick={copyWallet}
                  className="p-2 rounded bg-[#f7931a]/20 hover:bg-[#f7931a]/30 text-[#f7931a]"
                >
                  <Copy className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Purchase Confirm Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="bg-[#020204] border border-[#00ffff]/50 text-white">
          <DialogHeader>
            <DialogTitle className="text-xl font-mono text-[#00ffff]">ONAYLA</DialogTitle>
            <DialogDescription className="text-slate-400">
              {selectedPlan && membershipPlans.find(p => p.id === selectedPlan)?.name} paketini satın almak istiyor musunuz?
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 mt-4">
            <div className="p-4 rounded-lg bg-black/50 border border-[#00ffff]/30">
              <div className="flex justify-between items-center mb-2">
                <span className="text-slate-400 font-mono">PAKET:</span>
                <span className="text-white font-bold">
                  {selectedPlan && membershipPlans.find(p => p.id === selectedPlan)?.name}
                </span>
              </div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-slate-400 font-mono">FIYAT:</span>
                <span className="text-white">
                  {selectedPlan && membershipPlans.find(p => p.id === selectedPlan)?.price.toLocaleString()} TRY
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400 font-mono">BTC:</span>
                <span className="text-[#f7931a] font-mono">
                  ≈ {selectedPlan && getBtcAmount(membershipPlans.find(p => p.id === selectedPlan)!.price)} BTC
                </span>
              </div>
            </div>

            <div className="flex items-start gap-2 p-3 rounded-lg bg-[#0088cc]/10 border border-[#0088cc]/30">
              <MessageCircle className="w-5 h-5 text-[#0088cc] flex-shrink-0 mt-0.5" />
              <p className="text-[#0088cc] text-sm">
                Ödeme yapmadan önce Telegram @{TELEGRAM_CONTACT} üzerinden onay almayı unutmayın!
              </p>
            </div>

            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setShowDialog(false)}
                className="flex-1 border-[#ff00ff]/50 text-[#ff00ff] hover:bg-[#ff00ff]/10"
              >
                IPTAL
              </Button>
              <Button
                onClick={handlePurchase}
                className="flex-1 bg-[#00ff00] text-black hover:bg-[#00ff00]/80 font-bold"
              >
                DEVAM ET
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Payment Dialog */}
      <Dialog open={showPaymentDialog} onOpenChange={setShowPaymentDialog}>
        <DialogContent className="bg-[#020204] border border-[#f7931a]/50 text-white max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-xl font-mono text-[#f7931a] flex items-center gap-2">
              <Bitcoin className="w-6 h-6" />
              BITCOIN ODEME
            </DialogTitle>
            <DialogDescription className="text-slate-400">
              Aşağıdaki adrese ödeme yapın ve ardından Telegram üzerinden bildirin.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 mt-4">
            <div className="p-4 bg-black/50 rounded-lg border border-[#f7931a]/30">
              <p className="text-xs text-slate-500 mb-2 font-mono">GONDERILECEK TUTAR:</p>
              <p className="text-2xl font-bold text-[#f7931a] font-mono">{btcPrice} BTC</p>
              <p className="text-sm text-slate-400">
                ≈ {selectedPlan && membershipPlans.find(p => p.id === selectedPlan)?.price.toLocaleString()} TRY
              </p>
            </div>

            <div className="p-4 bg-black/50 rounded-lg border border-[#f7931a]/30">
              <p className="text-xs text-slate-500 mb-2 font-mono">BTC ADRESI:</p>
              <div className="flex items-center gap-2">
                <code className="flex-1 text-[#f7931a] font-mono text-sm break-all">
                  {BITCOIN_WALLET}
                </code>
                <button
                  onClick={copyWallet}
                  className="p-2 rounded bg-[#f7931a]/20 hover:bg-[#f7931a]/30 text-[#f7931a]"
                >
                  <Copy className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="flex items-start gap-2 p-3 rounded-lg bg-[#ffff00]/10 border border-[#ffff00]/30">
              <AlertCircle className="w-5 h-5 text-[#ffff00] flex-shrink-0 mt-0.5" />
              <div className="text-sm text-[#ffff00]">
                <p className="font-bold mb-1">ONEMLI:</p>
                <ul className="list-disc list-inside space-y-1">
                  <li>Sadece Bitcoin (BTC) ağı kullanın</li>
                  <li>Ödeme sonrası TX ID&apos;yi Telegram&apos;a gönderin</li>
                  <li>Onay süresi ortalama 10-30 dakikadır</li>
                </ul>
              </div>
            </div>

            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setShowPaymentDialog(false)}
                className="flex-1 border-slate-600 text-slate-400"
              >
                KAPAT
              </Button>
              <a
                href={`https://t.me/${TELEGRAM_CONTACT}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1"
              >
                <Button className="w-full bg-[#0088cc] text-white hover:bg-[#0088cc]/80">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  TELEGRAM
                </Button>
              </a>
            </div>

            {/* Demo Button - Remove in production */}
            <Button
              onClick={confirmPayment}
              className="w-full bg-[#00ff00]/20 text-[#00ff00] border border-[#00ff00]/50 hover:bg-[#00ff00]/30"
            >
              [DEMO] ODEMEYI ONAYLA
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
