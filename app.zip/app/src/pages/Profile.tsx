// ============================================
// THCpanel - Profile Page
// ============================================

import { useState, useRef } from 'react';
import { 
  User, Camera, Edit2, Save, X, Crown, Star, Trophy, 
  Target, Zap, Shield, Award, Medal, Gem
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import type { User as UserType, Badge } from '@/types';
import { updateUser, getLevelInfo, getUserQueries } from '@/utils/database';

interface ProfileProps {
  user: UserType | null;
  onUserUpdate: () => void;
}

const badgeIcons: Record<string, React.ElementType> = {
  Crown, Star, Trophy, Target, Zap, Shield, Award, Medal, Gem
};

export default function Profile({ user, onUserUpdate }: ProfileProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [bio, setBio] = useState(user?.bio || '');
  const [customTitle, setCustomTitle] = useState(user?.customTitle || '');
  const [avatarPreview, setAvatarPreview] = useState(user?.avatar || '');
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!user) return null;

  const levelInfo = getLevelInfo(user.xp);
  const userQueries = getUserQueries(user.id);
  const xpProgress = ((user.xp - levelInfo.minXP) / (levelInfo.maxXP - levelInfo.minXP)) * 100;

  const handleAvatarClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatarPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    updateUser(user.id, {
      bio,
      customTitle,
      avatar: avatarPreview
    });
    onUserUpdate();
    setIsEditing(false);
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'founder': return 'from-[#ff0040] to-[#ff4000]';
      case 'admin': return 'from-[#ff00ff] to-[#ff40ff]';
      case 'vendor': return 'from-[#00ff00] to-[#40ff40]';
      case 'elmas': return 'from-[#00ffff] to-[#40ffff]';
      case 'vip': return 'from-[#ffff00] to-[#ffff40]';
      default: return 'from-slate-600 to-slate-500';
    }
  };

  return (
    <div className="p-6 min-h-screen bg-[#020204]">
      {/* Background */}
      <div 
        className="fixed inset-0 opacity-5 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(rgba(0, 255, 255, 0.3) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255, 0, 255, 0.3) 1px, transparent 1px)
          `,
          backgroundSize: '40px 40px'
        }}
      />

      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-2 flex items-center gap-3 font-mono">
          <User className="w-8 h-8 text-[#00ffff]" />
          <span className="text-[#00ffff]">PROFIL</span>
        </h1>
        <p className="text-slate-400 font-mono">
          Profilinizi ozellestirin ve basarilarinizi gorun
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Profile Card */}
        <div className="lg:col-span-1">
          <div className="bg-black/80 border border-[#00ffff]/30 rounded-xl p-6 cyber-card relative">
            {/* Edit Button */}
            <button
              onClick={() => isEditing ? handleSave() : setIsEditing(true)}
              className="absolute top-4 right-4 p-2 rounded-lg bg-[#00ffff]/20 text-[#00ffff] hover:bg-[#00ffff]/30"
            >
              {isEditing ? <Save className="w-4 h-4" /> : <Edit2 className="w-4 h-4" />}
            </button>

            {/* Avatar */}
            <div className="flex justify-center mb-6">
              <div 
                className="relative w-32 h-32 rounded-full overflow-hidden border-4 border-[#00ffff]/50 cursor-pointer group"
                onClick={isEditing ? handleAvatarClick : undefined}
              >
                {avatarPreview ? (
                  <img 
                    src={avatarPreview} 
                    alt="Avatar" 
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full bg-gradient-to-br from-[#00ffff] to-[#ff00ff] flex items-center justify-center text-black text-4xl font-bold">
                    {user.username.charAt(0).toUpperCase()}
                  </div>
                )}
                
                {isEditing && (
                  <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                    <Camera className="w-8 h-8 text-white" />
                  </div>
                )}
              </div>
              
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                className="hidden"
              />
            </div>

            {/* Username & Role */}
            <div className="text-center mb-6">
              <h2 className="text-2xl font-bold text-white font-mono">{user.username}</h2>
              <div className={`inline-block px-3 py-1 rounded-full bg-gradient-to-r ${getRoleColor(user.role)} text-black text-xs font-bold mt-2`}>
                {user.role.toUpperCase()}
              </div>
              
              {isEditing ? (
                <Input
                  value={customTitle}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setCustomTitle(e.target.value)}
                  placeholder="Ozel unvaniniz"
                  className="mt-2 bg-black/50 border-[#00ffff]/50 text-white text-center text-sm font-mono"
                />
              ) : customTitle && (
                <p className="text-[#00ffff] text-sm mt-2 font-mono">"{customTitle}"</p>
              )}
            </div>

            {/* Bio */}
            <div className="mb-4">
              <Label className="text-[#00ffff] text-xs font-mono mb-1 block">BIOGRAFI</Label>
              {isEditing ? (
                <textarea
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  placeholder="Kendinizden bahsedin..."
                  className="w-full h-24 bg-black/50 border border-[#00ffff]/50 rounded-lg p-3 text-white text-sm font-mono resize-none"
                />
              ) : (
                <p className="text-slate-400 text-sm">{bio || 'Biyografi eklenmemis.'}</p>
              )}
            </div>

            {/* Member Since */}
            <div className="text-center text-xs text-slate-500 font-mono">
              Uye since: {new Date(user.createdAt).toLocaleDateString('tr-TR')}
            </div>

            {isEditing && (
              <div className="flex gap-2 mt-4">
                <Button
                  onClick={() => setIsEditing(false)}
                  variant="outline"
                  className="flex-1 border-[#ff00ff]/50 text-[#ff00ff]"
                >
                  <X className="w-4 h-4 mr-2" />
                  IPTAL
                </Button>
                <Button
                  onClick={handleSave}
                  className="flex-1 bg-[#00ff00] text-black"
                >
                  <Save className="w-4 h-4 mr-2" />
                  KAYDET
                </Button>
              </div>
            )}
          </div>
        </div>

        {/* Stats & Level */}
        <div className="lg:col-span-2 space-y-6">
          {/* Level Card */}
          <div className="bg-black/80 border border-[#00ffff]/30 rounded-xl p-6 cyber-card">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-white flex items-center gap-2 font-mono">
                <Target className="w-5 h-5 text-[#00ffff]" />
                SEVIYE {user.level}
              </h3>
              <span className="text-[#00ffff] font-mono">{levelInfo.name}</span>
            </div>

            {/* XP Progress */}
            <div className="mb-4">
              <div className="flex justify-between text-sm mb-2">
                <span className="text-slate-400 font-mono">XP: {user.xp.toLocaleString()}</span>
                <span className="text-slate-400 font-mono">
                  {levelInfo.maxXP === 999999 ? 'MAX' : `${levelInfo.maxXP.toLocaleString()} XP`}
                </span>
              </div>
              <div className="h-4 bg-black/50 rounded-full overflow-hidden border border-[#00ffff]/30">
                <div 
                  className="h-full bg-gradient-to-r from-[#00ffff] to-[#ff00ff] transition-all duration-500"
                  style={{ width: `${Math.min(xpProgress, 100)}%` }}
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="text-center p-3 bg-white/5 rounded-lg">
                <p className="text-2xl font-bold text-[#00ffff]">{user.totalQueries.toLocaleString()}</p>
                <p className="text-xs text-slate-500 font-mono">TOPLAM SORGU</p>
              </div>
              <div className="text-center p-3 bg-white/5 rounded-lg">
                <p className="text-2xl font-bold text-[#ff00ff]">{userQueries.length}</p>
                <p className="text-xs text-slate-500 font-mono">BU AY</p>
              </div>
              <div className="text-center p-3 bg-white/5 rounded-lg">
                <p className="text-2xl font-bold text-[#ffff00]">{user.badges.length}</p>
                <p className="text-xs text-slate-500 font-mono">ROZET</p>
              </div>
            </div>
          </div>

          {/* Badges */}
          <div className="bg-black/80 border border-[#00ffff]/30 rounded-xl p-6 cyber-card">
            <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2 font-mono">
              <Award className="w-5 h-5 text-[#ffff00]" />
              KAZANILAN ROZETLER
            </h3>

            {user.badges.length === 0 ? (
              <div className="text-center py-8 text-slate-500">
                <Award className="w-12 h-12 mx-auto mb-2 opacity-30" />
                <p className="text-sm font-mono">Heniz rozet kazanmadiniz</p>
                <p className="text-xs">Sorgu yaparak rozetler kazanin!</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {user.badges.map((badge: Badge) => {
                  const Icon = badgeIcons[badge.icon] || Star;
                  
                  return (
                    <div 
                      key={badge.id}
                      className="p-4 bg-white/5 rounded-lg border border-white/10 hover:border-[#00ffff]/50 transition-colors text-center group"
                    >
                      <div 
                        className="w-12 h-12 mx-auto mb-2 rounded-full flex items-center justify-center"
                        style={{ background: `${badge.color}30` }}
                      >
                        <Icon className="w-6 h-6" style={{ color: badge.color }} />
                      </div>
                      <p className="text-white text-sm font-bold">{badge.name}</p>
                      <p className="text-xs text-slate-500">{badge.description}</p>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* How to Earn XP */}
          <div className="bg-black/80 border border-[#00ff00]/30 rounded-xl p-6 cyber-card">
            <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2 font-mono">
              <Zap className="w-5 h-5 text-[#00ff00]" />
              XP KAZANMA YOLLARI
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                { action: 'Ucretsiz Sorgu', xp: '+5 XP', color: '#00ff00' },
                { action: 'Premium Sorgu', xp: '+10-25 XP', color: '#ff00ff' },
                { action: 'Gunluk Giris', xp: '+10 XP', color: '#00ffff' },
                { action: 'Profil Tamamla', xp: '+50 XP', color: '#ffff00' },
              ].map((item, i) => (
                <div key={i} className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                  <span className="text-slate-300">{item.action}</span>
                  <span className="font-bold font-mono" style={{ color: item.color }}>{item.xp}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
