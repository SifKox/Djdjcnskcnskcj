import { useState } from 'react';
import {
  Search,
  User as UserIcon,
  Phone,
  MapPin,
  Car,
  Globe,
  Mail,
  Database,
  Shield,
  AlertCircle,
  CheckCircle,
  Copy,
  Download,
  Lock,
  CreditCard,
  BookOpen,
  Share2,
  Crown,
  Gem
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import type { User as UserType, QueryType } from '@/types';
import { addQuery, generateId, canAccessQuery, queryCategories } from '@/utils/database';

interface QueriesProps {
  user: UserType | null;
}

interface QueryResult {
  success: boolean;
  data?: Record<string, string>;
  message: string;
}

const iconMap: Record<string, React.ElementType> = {
  User: UserIcon, Phone, MapPin, Car, Globe, Mail, CreditCard, BookOpen, Share2
};

// Mock data generator
const generateMockData = (type: QueryType, input: string): Record<string, string> => {
  const mockNames = ['AHMET YILMAZ', 'MEHMET KAYA', 'AYŞE DEMIR', 'FATMA ŞAHIN', 'ALI ÖZDEMIR'];
  const mockCities = ['ISTANBUL', 'ANKARA', 'IZMIR', 'BURSA', 'ANTALYA'];
  const mockPhones = ['5551234567', '5329876543', '5365558877', '5384442233'];
  
  switch (type) {
    case 'tc':
      return {
        AD_SOYAD: mockNames[Math.floor(Math.random() * mockNames.length)],
        TC_KIMLIK: input,
        DOGUM_TARIHI: '01/01/1990',
        IL: mockCities[Math.floor(Math.random() * mockCities.length)],
        ILCE: 'MERKEZ',
        TELEFON: '0' + mockPhones[Math.floor(Math.random() * mockPhones.length)],
        ADRES: `${mockCities[Math.floor(Math.random() * mockCities.length)]} MERKEZ MAH. ORNEK SK. NO:${Math.floor(Math.random() * 100) + 1}`
      };
    case 'gsm':
      return {
        AD_SOYAD: mockNames[Math.floor(Math.random() * mockNames.length)],
        TC_KIMLIK: `${Math.floor(Math.random() * 90000000000) + 10000000000}`,
        TELEFON: input,
        OPERATOR: ['TURKCELL', 'VODAFONE', 'TURK TELEKOM'][Math.floor(Math.random() * 3)],
        IL: mockCities[Math.floor(Math.random() * mockCities.length)]
      };
    case 'adres':
      return {
        AD_SOYAD: mockNames[Math.floor(Math.random() * mockNames.length)],
        TC_KIMLIK: `${Math.floor(Math.random() * 90000000000) + 10000000000}`,
        ADRES: input.toUpperCase(),
        IL: mockCities[Math.floor(Math.random() * mockCities.length)],
        ILCE: 'MERKEZ',
        TELEFON: '0' + mockPhones[Math.floor(Math.random() * mockPhones.length)]
      };
    case 'plaka':
      return {
        PLAKA: input.toUpperCase(),
        MARKA: ['BMW', 'MERCEDES', 'AUDI', 'TOYOTA', 'HONDA'][Math.floor(Math.random() * 5)],
        MODEL: ['2020', '2021', '2022', '2023'][Math.floor(Math.random() * 4)],
        RENK: ['SIYAH', 'BEYAZ', 'GRI', 'KIRMIZI'][Math.floor(Math.random() * 4)],
        SAHIP: mockNames[Math.floor(Math.random() * mockNames.length)],
        TC_KIMLIK: `${Math.floor(Math.random() * 90000000000) + 10000000000}`
      };
    case 'ip':
      return {
        IP_ADRESI: input,
        ULKE: 'TURKIYE',
        SEHIR: mockCities[Math.floor(Math.random() * mockCities.length)],
        ISP: ['TURKCELL', 'VODAFONE', 'TURK TELEKOM', 'SUPERONLINE'][Math.floor(Math.random() * 4)],
        TIP: 'STATIK'
      };
    case 'email':
      return {
        EMAIL: input.toLowerCase(),
        AD_SOYAD: mockNames[Math.floor(Math.random() * mockNames.length)],
        KAYIT_TARIHI: '2020-01-01',
        SON_GIRIS: '2025-01-15',
        DURUM: 'AKTIF'
      };
    case 'iban':
      return {
        IBAN: input,
        AD_SOYAD: mockNames[Math.floor(Math.random() * mockNames.length)],
        BANKA: ['ZIRAAT', 'GARANTI', 'IS', 'AKBANK', 'YAPI KREDI'][Math.floor(Math.random() * 5)],
        HESAP_TIPI: 'VADESIZ',
        DURUM: 'AKTIF'
      };
    case 'pasaport':
      return {
        PASAPORT_NO: input.toUpperCase(),
        AD_SOYAD: mockNames[Math.floor(Math.random() * mockNames.length)],
        UYRUK: 'TC',
        DOGUM_TARIHI: '01/01/1990',
        GECERLILIK: '2030-01-01'
      };
    case 'sosyalmedya':
      return {
        KULLANICI_ADI: input,
        INSTAGRAM: '@' + input,
        TWITTER: '@' + input,
        FACEBOOK: 'fb.com/' + input,
        TIKTOK: '@' + input,
        TELEGRAM: '@' + input
      };
    default:
      return {};
  }
};

export default function Queries({ user }: QueriesProps) {
  const [activeTab, setActiveTab] = useState('free');
  const [activeQuery, setActiveQuery] = useState<string | null>(null);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<QueryResult | null>(null);
  const [error, setError] = useState('');

  const handleQuery = async (type: QueryType, requires: 'free' | 'vip' | 'elmas') => {
    setError('');
    setResult(null);

    if (!input.trim()) {
      setError('LUTFEN DEGER GIRIN');
      return;
    }

    if (!canAccessQuery(user, requires)) {
      setError('BU SORGU ICIN UYELIK GEREKLI');
      return;
    }

    setLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1500));

    const mockData = generateMockData(type, input);

    addQuery({
      id: generateId(),
      userId: user?.id || '',
      username: user?.username || '',
      queryType: type,
      queryInput: input,
      result: JSON.stringify(mockData),
      timestamp: new Date(),
      xpEarned: 5
    });

    setResult({
      success: true,
      data: mockData,
      message: 'SORGU BASARILI'
    });

    setLoading(false);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <div className="p-6 min-h-screen bg-[#020204]">
      {/* Background */}
      <div 
        className="fixed inset-0 opacity-5 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(rgba(0, 255, 255, 0.3) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255, 0, 255, 0.3) 1px, transparent 1px)
          `,
          backgroundSize: '40px 40px'
        }}
      />

      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-2 flex items-center gap-3 font-mono">
          <Database className="w-8 h-8 text-[#00ffff]" />
          <span className="text-[#00ffff]">SORGU</span>
          <span className="text-[#ff00ff]">MERKEZI</span>
        </h1>
        <p className="text-slate-400 font-mono">
          Ucretsiz ve Premium sorgu araçları
        </p>
      </div>

      {/* Category Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 max-w-md mb-6 bg-black/50 border border-[#00ffff]/30">
          <TabsTrigger 
            value="free" 
            className="data-[state=active]:bg-[#00ff00]/20 data-[state=active]:text-[#00ff00] text-slate-400 font-mono"
          >
            <Lock className="w-4 h-4 mr-2" />
            UCRETSIZ
          </TabsTrigger>
          <TabsTrigger 
            value="premium"
            className="data-[state=active]:bg-[#ff00ff]/20 data-[state=active]:text-[#ff00ff] text-slate-400 font-mono"
          >
            <Crown className="w-4 h-4 mr-2" />
            PREMIUM
          </TabsTrigger>
        </TabsList>

        {queryCategories.map((category) => (
          <TabsContent key={category.id} value={category.id}>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Query Selection */}
              <div className="bg-black/80 border border-[#00ffff]/30 rounded-xl p-6 cyber-card">
                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2 font-mono">
                  {category.isPremium ? <Gem className="w-5 h-5 text-[#ff00ff]" /> : <Lock className="w-5 h-5 text-[#00ff00]" />}
                  {category.name}
                </h3>
                <p className="text-slate-400 text-sm mb-4">{category.description}</p>

                <div className="space-y-2">
                  {category.queries.map((query) => {
                    const Icon = iconMap[query.icon] || Database;
                    const hasAccess = canAccessQuery(user, query.requiresMembership);
                    
                    return (
                      <button
                        key={query.id}
                        onClick={() => {
                          setActiveQuery(query.id);
                          setInput('');
                          setResult(null);
                          setError('');
                        }}
                        className={`w-full flex items-center gap-3 p-3 rounded-lg border transition-all duration-200 text-left ${
                          activeQuery === query.id
                            ? 'bg-[#00ffff]/20 border-[#00ffff] text-white'
                            : 'bg-white/5 border-transparent text-slate-400 hover:bg-white/10 hover:text-white'
                        }`}
                      >
                        <Icon className="w-5 h-5" />
                        <div className="flex-1">
                          <p className="font-bold text-sm">{query.name}</p>
                          <p className="text-xs text-slate-500">{query.description}</p>
                        </div>
                        {!hasAccess && (
                          <Lock className="w-4 h-4 text-[#ff00ff]" />
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Query Form */}
              <div className="bg-black/80 border border-[#00ffff]/30 rounded-xl p-6 cyber-card">
                {activeQuery ? (
                  <>
                    {(() => {
                      const query = category.queries.find(q => q.id === activeQuery);
                      if (!query) return null;
                      const Icon = iconMap[query.icon] || Database;
                      const hasAccess = canAccessQuery(user, query.requiresMembership);

                      return (
                        <>
                          <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2 font-mono">
                            <Icon className="w-5 h-5 text-[#00ffff]" />
                            {query.name}
                          </h3>

                          <div className="space-y-4">
                            <div>
                              <Label className="text-[#00ffff] text-xs font-mono mb-2 block">
                                {query.placeholder}
                              </Label>
                              <div className="flex gap-3">
                                <Input
                                  type="text"
                                  value={input}
                                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setInput(e.target.value)}
                                  placeholder={query.placeholder}
                                  disabled={!hasAccess}
                                  className="flex-1 bg-black/50 border-[#00ffff]/50 text-white placeholder:text-slate-600 focus:border-[#00ffff] font-mono disabled:opacity-50"
                                />
                                <Button
                                  onClick={() => handleQuery(query.id, query.requiresMembership)}
                                  disabled={loading || !hasAccess}
                                  className="cyber-btn"
                                >
                                  {loading ? (
                                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                                  ) : (
                                    <Search className="w-5 h-5" />
                                  )}
                                </Button>
                              </div>
                            </div>

                            {!hasAccess && (
                              <div className="p-4 bg-[#ff00ff]/10 border border-[#ff00ff]/30 rounded-lg">
                                <div className="flex items-center gap-2 mb-2">
                                  <Lock className="w-5 h-5 text-[#ff00ff]" />
                                  <span className="text-[#ff00ff] font-bold">ERISIM KISITLI</span>
                                </div>
                                <p className="text-sm text-slate-400 mb-3">
                                  Bu sorgu {query.requiresMembership.toUpperCase()} üyelik gerektirir.
                                </p>
                                <Button 
                                  onClick={() => window.location.href = '#/market'}
                                  className="w-full bg-[#ff00ff] text-black hover:bg-[#ff00ff]/80"
                                >
                                  <Crown className="w-4 h-4 mr-2" />
                                  UYELIK AL
                                </Button>
                              </div>
                            )}

                            {error && (
                              <div className="flex items-center gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/50 text-red-400 text-sm font-mono">
                                <AlertCircle className="w-4 h-4" />
                                &gt; ERROR: {error}
                              </div>
                            )}

                            <div className="p-4 rounded-lg bg-black/50 border border-[#00ffff]/20">
                              <h4 className="text-sm font-bold text-[#00ffff] mb-2 flex items-center gap-2 font-mono">
                                <Shield className="w-4 h-4" />
                                SORGU KURALLARI
                              </h4>
                              <ul className="text-xs text-slate-500 space-y-1 font-mono">
                                <li>&gt; Sorgular sisteme kaydedilir</li>
                                <li>&gt; Gunluk limit uyelige gore belirlenir</li>
                                <li>&gt; Yanlis kullanim hesap kapatilmasina neden olur</li>
                                <li>&gt; Tum veriler sifrelenir</li>
                              </ul>
                            </div>
                          </div>
                        </>
                      );
                    })()}
                  </>
                ) : (
                  <div className="flex flex-col items-center justify-center py-12 text-slate-500">
                    <Database className="w-16 h-16 mb-4 opacity-30" />
                    <p className="font-mono">Sorgu secin</p>
                  </div>
                )}
              </div>
            </div>

            {/* Results */}
            {result && result.success && result.data && (
              <div className="mt-6 bg-black/80 border border-[#00ff00]/30 rounded-xl p-6 cyber-card">
                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2 font-mono">
                  <CheckCircle className="w-5 h-5 text-[#00ff00]" />
                  SORGU_SONUCU
                </h3>

                <div className="space-y-2">
                  <div className="flex items-center gap-2 p-3 rounded-lg bg-[#00ff00]/10 border border-[#00ff00]/30 text-[#00ff00] text-sm font-mono">
                    <CheckCircle className="w-4 h-4" />
                    &gt; {result.message}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {Object.entries(result.data).map(([key, value]) => (
                      <div
                        key={key}
                        className="flex items-center justify-between p-3 rounded-lg bg-white/5 hover:bg-white/10 transition-colors group"
                      >
                        <div>
                          <p className="text-[10px] text-[#00ffff] font-mono uppercase">{key}</p>
                          <p className="text-white font-mono">{String(value)}</p>
                        </div>
                        <button
                          onClick={() => copyToClipboard(String(value))}
                          className="opacity-0 group-hover:opacity-100 p-2 rounded hover:bg-white/10 transition-all"
                        >
                          <Copy className="w-4 h-4 text-[#00ffff]" />
                        </button>
                      </div>
                    ))}
                  </div>

                  <Button
                    variant="outline"
                    className="w-full border-[#00ffff]/30 text-[#00ffff] hover:bg-[#00ffff]/10"
                    onClick={() => {
                      const dataStr = JSON.stringify(result.data, null, 2);
                      const blob = new Blob([dataStr], { type: 'application/json' });
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement('a');
                      a.href = url;
                      a.download = `sorgu-${activeQuery}-${Date.now()}.json`;
                      a.click();
                    }}
                  >
                    <Download className="w-4 h-4 mr-2" />
                    SONUCU INDIR
                  </Button>
                </div>
              </div>
            )}
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
