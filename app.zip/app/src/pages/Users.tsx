import { useState, useEffect } from 'react';
import {
  Users,
  Search,
  Crown,
  Gem,
  Shield,
  Activity,
  Mail,
  Calendar
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import type { User } from '@/types';
import { getUsers } from '@/utils/database';

export default function UsersPage() {
  const [users, setUsers] = useState<User[]>([]);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    setUsers(getUsers());
  }, []);

  const filteredUsers = users.filter(u =>
    u.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'founder': return Crown;
      case 'admin': return Shield;
      case 'moderator': return Users;
      case 'elmas': return Gem;
      case 'vip': return Crown;
      default: return Activity;
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'founder': return 'text-amber-400';
      case 'admin': return 'text-red-400';
      case 'moderator': return 'text-blue-400';
      case 'elmas': return 'text-cyan-400';
      case 'vip': return 'text-purple-400';
      default: return 'text-slate-400';
    }
  };

  return (
    <div className="p-8 max-w-6xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-2 flex items-center gap-3">
          <Users className="w-8 h-8 text-purple-400" />
          Kullanıcılar
        </h1>
        <p className="text-slate-400">
          Tüm kullanıcıları görüntüleyin ve yönetin
        </p>
      </div>

      {/* Search */}
      <div className="mb-6">
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <Input
            type="text"
            value={searchTerm}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchTerm(e.target.value)}
            placeholder="Kullanıcı ara..."
            className="pl-10 bg-slate-800/50 border-white/10 text-white"
          />
        </div>
      </div>

      {/* Users Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredUsers.map((u) => {
          const RoleIcon = getRoleIcon(u.role);
          return (
            <div
              key={u.id}
              className="bg-slate-900/80 backdrop-blur border border-white/5 rounded-xl p-5 hover:border-white/10 transition-colors"
            >
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-600 to-cyan-600 flex items-center justify-center text-white text-lg font-bold">
                  {u.username.charAt(0).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="text-white font-medium truncate">{u.username}</h3>
                    <RoleIcon className={`w-4 h-4 ${getRoleColor(u.role)}`} />
                  </div>
                  <div className="flex items-center gap-1 text-slate-500 text-sm mt-1">
                    <Mail className="w-3 h-3" />
                    <span className="truncate">{u.email}</span>
                  </div>
                  <div className="flex items-center gap-1 text-slate-500 text-sm mt-1">
                    <Calendar className="w-3 h-3" />
                    <span>{new Date(u.createdAt).toLocaleDateString('tr-TR')}</span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-white/5 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {u.membershipType === 'elmas' ? (
                    <span className="flex items-center gap-1 px-2 py-1 rounded-full bg-cyan-500/20 text-cyan-400 text-xs">
                      <Gem className="w-3 h-3" /> Elmas
                    </span>
                  ) : u.membershipType === 'vip' ? (
                    <span className="flex items-center gap-1 px-2 py-1 rounded-full bg-purple-500/20 text-purple-400 text-xs">
                      <Crown className="w-3 h-3" /> VIP
                    </span>
                  ) : (
                    <span className="px-2 py-1 rounded-full bg-slate-500/20 text-slate-400 text-xs">
                      Standart
                    </span>
                  )}
                </div>
                <div className={`w-2 h-2 rounded-full ${u.isActive ? 'bg-emerald-400' : 'bg-red-400'}`} />
              </div>
            </div>
          );
        })}
      </div>

      {filteredUsers.length === 0 && (
        <div className="text-center py-12">
          <Users className="w-16 h-16 text-slate-600 mx-auto mb-4" />
          <p className="text-slate-500">Kullanıcı bulunamadı</p>
        </div>
      )}
    </div>
  );
}
