// ============================================
// THCpanel - Main Types
// ============================================

export interface User {
  id: string;
  username: string;
  password: string;
  email: string;
  role: 'founder' | 'admin' | 'vendor' | 'moderator' | 'vip' | 'elmas' | 'user';
  membershipType?: 'none' | 'vip' | 'elmas' | 'vendor';
  membershipExpiry?: Date;
  createdAt: Date;
  lastLogin?: Date;
  isActive: boolean;
  isApproved: boolean; // Owner approval required
  approvedBy?: string;
  approvedAt?: Date;
  permissions: string[];
  telegram?: string;
  // Profile customization
  avatar?: string;
  bio?: string;
  customTitle?: string;
  // XP System
  xp: number;
  level: number;
  badges: Badge[];
  totalQueries: number;
  // Security
  lastIp?: string;
  loginAttempts: number;
  lockedUntil?: Date;
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  unlockedAt: Date;
}

export interface Log {
  id: string;
  userId: string;
  username: string;
  action: string;
  details: string;
  timestamp: Date;
  ip?: string;
  userAgent?: string;
}

export interface QueryRecord {
  id: string;
  userId: string;
  username: string;
  queryType: string;
  queryInput: string;
  result?: string;
  timestamp: Date;
  xpEarned: number;
}

export interface MembershipPlan {
  id: string;
  name: string;
  price: number;
  duration: number;
  features: string[];
  color: string;
  type: 'weekly' | 'monthly' | 'yearly' | 'unlimited' | 'vendor';
}

export interface AuthState {
  isAuthenticated: boolean;
  user: User | null;
  token: string | null;
}

export interface BitcoinPayment {
  id: string;
  userId: string;
  username: string;
  planId: string;
  planName: string;
  amount: number;
  btcAmount: number;
  btcAddress: string;
  status: 'pending' | 'confirmed' | 'expired';
  createdAt: Date;
  expiresAt: Date;
  txHash?: string;
}

export interface ChatMessage {
  id: string;
  userId: string;
  username: string;
  avatar?: string;
  message: string;
  timestamp: Date;
  isEncrypted: boolean;
}

export type QueryType = 
  | 'tc' | 'gsm' | 'adres' | 'plaka' | 'ip' | 'email' 
  | 'iban' | 'pasaport' | 'sosyalmedya' | 'tapu' | 'sgk' 
  | 'vergi' | 'kredi' | 'aile' | 'okul' | 'isyeri' 
  | 'hastane' | 'eczane' | 'nobetci' | 'havaalani' 
  | 'otobus' | 'tren' | 'arackaza' | 'trafikceza'
  | 'ehliyet' | 'pasaport' | 'kimlik' | 'dogum' 
  | 'olum' | 'evlilik' | 'bosanma' | 'vatandaslik'
  | 'sicil' | 'adli' | 'polis' | 'jandarma'
  | 'asker' | 'bedelli' | 'tecil' | 'muaf'
  | 'universite' | 'osym' | 'eokul' | 'meb'
  | 'hastane' | 'hastalik' | 'ilac' | 'recete'
  | 'sigorta' | 'kasko' | 'trafik' | 'dask'
  | 'banka' | 'kredi' | 'kredikarti' | 'hesap'
  | 'borsa' | 'kripto' | 'doviz' | 'altin'
  | 'emlak' | 'kira' | 'tapu' | 'imar'
  | 'araba' | 'motosiklet' | 'kamyon' | 'otobus'
  | 'gemi' | 'ucak' | 'tren' | 'metro'
  | 'telefon' | 'internet' | 'tv' | 'radio'
  | 'gazete' | 'dergi' | 'kitap' | 'yayin'
  | 'sosyal' | 'facebook' | 'twitter' | 'instagram'
  | 'youtube' | 'tiktok' | 'snapchat' | 'whatsapp'
  | 'telegram' | 'discord' | 'reddit' | 'linkedin'
  | 'github' | 'gitlab' | 'bitbucket' | 'stackoverflow'
  | 'steam' | 'epic' | 'origin' | 'uplay'
  | 'xbox' | 'playstation' | 'nintendo' | 'mobile'
  | 'spotify' | 'apple' | 'google' | 'microsoft'
  | 'amazon' | 'ebay' | 'aliexpress' | 'trendyol'
  | 'hepsiburada' | 'n11' | 'gittigidiyor' | 'sahibinden'
  | 'letgo' | 'dolap' | 'gardrops' | 'modanisa'
  | 'yemeksepeti' | 'getir' | 'migros' | 'carrefour'
  | 'a101' | 'bim' | 'sok' | 'sepet'
  | 'thy' | 'pegasus' | 'anadolujet' | 'sunexpress'
  | 'uber' | 'biTaksi' | 'scooter' | 'bisiklet'
  | 'hotel' | 'booking' | 'airbnb' | 'trivago'
  | 'firsat' | 'groupon' | 'citydeal' | 'indirim'
  | 'kupon' | 'hediye' | 'kampanya' | 'cekilis'
  | 'piyango' | 'sayisal' | 'super' | 'sanal'
  | 'iddaa' | 'bilyoner' | 'misli' | 'tuttur'
  | 'nesine' | 'bets10' | 'youwin' | 'tempobet';

export interface QueryCategory {
  id: string;
  name: string;
  description: string;
  queries: QueryItem[];
  isPremium: boolean;
}

export interface QueryItem {
  id: QueryType;
  name: string;
  description: string;
  icon: string;
  placeholder: string;
  pattern?: string;
  requiresMembership: 'free' | 'vip' | 'elmas';
  xpReward: number;
  // API Integration Placeholder
  apiEndpoint?: string;
  apiMethod?: 'GET' | 'POST';
  apiHeaders?: Record<string, string>;
}

export interface QueryFormData {
  type: QueryType;
  input: string;
}

export interface SecurityConfig {
  ddosProtection: boolean;
  ipMasking: boolean;
  encryptionEnabled: boolean;
  logRetention: number;
  maxLoginAttempts: number;
  lockoutDuration: number;
}

export interface XPLevel {
  level: number;
  name: string;
  minXP: number;
  maxXP: number;
  badge: string;
  color: string;
}
