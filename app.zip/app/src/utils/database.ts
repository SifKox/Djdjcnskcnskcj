// ============================================
// THCpanel - Database & State Management
// ============================================

import type { 
  User, Log, QueryRecord, MembershipPlan, 
  ChatMessage, QueryCategory, XPLevel, Badge 
} from '@/types';

// ============================================
// CONSTANTS
// ============================================

const DB_KEYS = {
  USERS: 'thcpanel_users_v2',
  LOGS: 'thcpanel_logs_v2',
  QUERIES: 'thcpanel_queries_v2',
  PAYMENTS: 'thcpanel_payments_v2',
  CHAT: 'thcpanel_chat_v2',
  SESSIONS: 'thcpanel_sessions_v2',
  CURRENT_USER: 'thcpanel_current_user_v2',
  SECURITY: 'thcpanel_security_v2',
  XP_LEVELS: 'thcpanel_xp_levels_v2'
};

// Bitcoin Wallet Address
export const BITCOIN_WALLET = 'bc1qzeew0lhchd8zlc5c6redz7txg83qwfwef5nysv';
export const TELEGRAM_CONTACT = 'venged7f';

// ============================================
// INITIALIZATION
// ============================================

export const initDatabase = () => {
  // Initialize users if not exists
  if (!localStorage.getItem(DB_KEYS.USERS)) {
    localStorage.setItem(DB_KEYS.USERS, JSON.stringify([]));
  }
  
  // Initialize logs if not exists
  if (!localStorage.getItem(DB_KEYS.LOGS)) {
    localStorage.setItem(DB_KEYS.LOGS, JSON.stringify([]));
  }
  
  // Initialize queries if not exists
  if (!localStorage.getItem(DB_KEYS.QUERIES)) {
    localStorage.setItem(DB_KEYS.QUERIES, JSON.stringify([]));
  }
  
  // Initialize chat if not exists
  if (!localStorage.getItem(DB_KEYS.CHAT)) {
    localStorage.setItem(DB_KEYS.CHAT, JSON.stringify([]));
  }
  
  // Initialize sessions if not exists
  if (!localStorage.getItem(DB_KEYS.SESSIONS)) {
    localStorage.setItem(DB_KEYS.SESSIONS, JSON.stringify({}));
  }

  // Initialize XP levels
  if (!localStorage.getItem(DB_KEYS.XP_LEVELS)) {
    localStorage.setItem(DB_KEYS.XP_LEVELS, JSON.stringify(xpLevels));
  }

  // Check if founder exists, if not create
  const users = getUsers();
  const founderExists = users.some(u => u.username === 'oyster');
  
  if (!founderExists) {
    const founder: User = {
      id: generateId(),
      username: 'oyster',
      password: 'fad183daz',
      email: 'founder@thcpanel.com',
      role: 'founder',
      membershipType: 'elmas',
      createdAt: new Date(),
      isActive: true,
      isApproved: true,
      approvedBy: 'system',
      approvedAt: new Date(),
      permissions: ['*'],
      telegram: TELEGRAM_CONTACT,
      xp: 999999,
      level: 99,
      badges: [
        { id: 'founder', name: 'KURUCU', description: 'Site kurucusu', icon: 'Crown', color: '#ff0040', unlockedAt: new Date() },
        { id: 'legend', name: 'EFSANE', description: 'Efsanevi kullanici', icon: 'Star', color: '#ffff00', unlockedAt: new Date() }
      ],
      totalQueries: 999999,
      loginAttempts: 0
    };
    
    users.push(founder);
    localStorage.setItem(DB_KEYS.USERS, JSON.stringify(users));
    
    addLog({
      id: generateId(),
      userId: founder.id,
      username: founder.username,
      action: 'SYSTEM_INIT',
      details: 'THCpanel v2.0 initialized - Founder account created',
      timestamp: new Date()
    });
  }
};

// ============================================
// HELPERS
// ============================================

export const generateId = () => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2, 9);
};

export const encryptData = (data: string): string => {
  // Simple XOR encryption for demo - replace with proper encryption in production
  const key = 'THCpanel_Secret_Key_2025';
  let encrypted = '';
  for (let i = 0; i < data.length; i++) {
    encrypted += String.fromCharCode(data.charCodeAt(i) ^ key.charCodeAt(i % key.length));
  }
  return btoa(encrypted);
};

export const decryptData = (data: string): string => {
  const key = 'THCpanel_Secret_Key_2025';
  const decoded = atob(data);
  let decrypted = '';
  for (let i = 0; i < decoded.length; i++) {
    decrypted += String.fromCharCode(decoded.charCodeAt(i) ^ key.charCodeAt(i % key.length));
  }
  return decrypted;
};

// ============================================
// USER OPERATIONS
// ============================================

export const getUsers = (): User[] => {
  const data = localStorage.getItem(DB_KEYS.USERS);
  return data ? JSON.parse(data) : [];
};

export const getUserByUsername = (username: string): User | undefined => {
  const users = getUsers();
  return users.find(u => u.username.toLowerCase() === username.toLowerCase());
};

export const getUserById = (id: string): User | undefined => {
  const users = getUsers();
  return users.find(u => u.id === id);
};

export const getPendingUsers = (): User[] => {
  const users = getUsers();
  return users.filter(u => !u.isApproved && u.role !== 'founder');
};

export const createUser = (userData: Omit<User, 'id' | 'createdAt' | 'isApproved' | 'xp' | 'level' | 'badges' | 'totalQueries' | 'loginAttempts'>): { success: boolean; message: string; user?: User } => {
  const users = getUsers();
  
  // Check if username exists
  if (users.some(u => u.username.toLowerCase() === userData.username.toLowerCase())) {
    return { success: false, message: 'Bu kullanici adi zaten kullaniliyor' };
  }
  
  // Check if email exists
  if (users.some(u => u.email.toLowerCase() === userData.email.toLowerCase())) {
    return { success: false, message: 'Bu e-posta zaten kullaniliyor' };
  }
  
  const newUser: User = {
    ...userData,
    id: generateId(),
    createdAt: new Date(),
    isApproved: false, // Requires owner approval
    xp: 0,
    level: 1,
    badges: [],
    totalQueries: 0,
    loginAttempts: 0
  };
  
  users.push(newUser);
  localStorage.setItem(DB_KEYS.USERS, JSON.stringify(users));
  
  addLog({
    id: generateId(),
    userId: newUser.id,
    username: newUser.username,
    action: 'USER_REGISTERED',
    details: `New user ${newUser.username} registered - Pending approval`,
    timestamp: new Date()
  });
  
  return { success: true, message: 'Kayit basarili! Hesabiniz onay icin bekliyor.', user: newUser };
};

export const approveUser = (userId: string, approvedBy: string): boolean => {
  const users = getUsers();
  const index = users.findIndex(u => u.id === userId);
  
  if (index === -1) return false;
  
  users[index].isApproved = true;
  users[index].approvedBy = approvedBy;
  users[index].approvedAt = new Date();
  
  localStorage.setItem(DB_KEYS.USERS, JSON.stringify(users));
  
  addLog({
    id: generateId(),
    userId,
    username: users[index].username,
    action: 'USER_APPROVED',
    details: `User ${users[index].username} approved by ${approvedBy}`,
    timestamp: new Date()
  });
  
  return true;
};

export const rejectUser = (userId: string, rejectedBy: string): boolean => {
  const users = getUsers();
  const index = users.findIndex(u => u.id === userId);
  
  if (index === -1) return false;
  
  const username = users[index].username;
  users.splice(index, 1);
  
  localStorage.setItem(DB_KEYS.USERS, JSON.stringify(users));
  
  addLog({
    id: generateId(),
    userId,
    username,
    action: 'USER_REJECTED',
    details: `User ${username} rejected by ${rejectedBy}`,
    timestamp: new Date()
  });
  
  return true;
};

export const updateUser = (userId: string, updates: Partial<User>): User | null => {
  const users = getUsers();
  const index = users.findIndex(u => u.id === userId);
  
  if (index === -1) return null;
  
  users[index] = { ...users[index], ...updates };
  localStorage.setItem(DB_KEYS.USERS, JSON.stringify(users));
  
  addLog({
    id: generateId(),
    userId,
    username: users[index].username,
    action: 'USER_UPDATED',
    details: `User updated: ${Object.keys(updates).join(', ')}`,
    timestamp: new Date()
  });
  
  return users[index];
};

export const deleteUser = (userId: string): boolean => {
  const users = getUsers();
  const user = users.find(u => u.id === userId);
  
  if (!user) return false;
  
  const filtered = users.filter(u => u.id !== userId);
  localStorage.setItem(DB_KEYS.USERS, JSON.stringify(filtered));
  
  // Clear all sessions for this user
  const sessions = getSessions();
  delete sessions[userId];
  localStorage.setItem(DB_KEYS.SESSIONS, JSON.stringify(sessions));
  
  addLog({
    id: generateId(),
    userId,
    username: user.username,
    action: 'USER_DELETED',
    details: `User ${user.username} deleted`,
    timestamp: new Date()
  });
  
  return true;
};

// ============================================
// SESSION MANAGEMENT (Multi-user support)
// ============================================

interface Session {
  userId: string;
  token: string;
  loginTime: Date;
  lastActivity: Date;
  ip?: string;
}

export const getSessions = (): Record<string, Session> => {
  const data = localStorage.getItem(DB_KEYS.SESSIONS);
  return data ? JSON.parse(data) : {};
};

export const createSession = (userId: string): string => {
  const sessions = getSessions();
  const token = generateId();
  
  sessions[userId] = {
    userId,
    token,
    loginTime: new Date(),
    lastActivity: new Date()
  };
  
  localStorage.setItem(DB_KEYS.SESSIONS, JSON.stringify(sessions));
  localStorage.setItem(DB_KEYS.CURRENT_USER, JSON.stringify(getUserById(userId)));
  
  return token;
};

export const validateSession = (userId: string, token: string): boolean => {
  const sessions = getSessions();
  const session = sessions[userId];
  
  if (!session) return false;
  if (session.token !== token) return false;
  
  // Update last activity
  session.lastActivity = new Date();
  sessions[userId] = session;
  localStorage.setItem(DB_KEYS.SESSIONS, JSON.stringify(sessions));
  
  return true;
};

export const clearSession = (userId?: string): void => {
  if (userId) {
    const sessions = getSessions();
    delete sessions[userId];
    localStorage.setItem(DB_KEYS.SESSIONS, JSON.stringify(sessions));
  }
  localStorage.removeItem(DB_KEYS.CURRENT_USER);
};

export const getCurrentUser = (): User | null => {
  const data = localStorage.getItem(DB_KEYS.CURRENT_USER);
  return data ? JSON.parse(data) : null;
};

// ============================================
// LOG OPERATIONS
// ============================================

export const getLogs = (): Log[] => {
  const data = localStorage.getItem(DB_KEYS.LOGS);
  return data ? JSON.parse(data) : [];
};

export const addLog = (log: Log): void => {
  const logs = getLogs();
  logs.unshift(log);
  if (logs.length > 1000) logs.pop();
  localStorage.setItem(DB_KEYS.LOGS, JSON.stringify(logs));
};

// ============================================
// QUERY OPERATIONS
// ============================================

export const getQueries = (): QueryRecord[] => {
  const data = localStorage.getItem(DB_KEYS.QUERIES);
  return data ? JSON.parse(data) : [];
};

export const addQuery = (query: QueryRecord): void => {
  const queries = getQueries();
  queries.unshift(query);
  if (queries.length > 5000) queries.pop(); // Increased limit
  localStorage.setItem(DB_KEYS.QUERIES, JSON.stringify(queries));
};

export const getUserQueries = (userId: string): QueryRecord[] => {
  const queries = getQueries();
  return queries.filter(q => q.userId === userId);
};

// ============================================
// CHAT OPERATIONS (Encrypted)
// ============================================

export const getChatMessages = (): ChatMessage[] => {
  const data = localStorage.getItem(DB_KEYS.CHAT);
  const messages = data ? JSON.parse(data) : [];
  // Decrypt messages
  return messages.map((msg: ChatMessage) => ({
    ...msg,
    message: msg.isEncrypted ? decryptData(msg.message) : msg.message
  }));
};

export const addChatMessage = (message: Omit<ChatMessage, 'id' | 'timestamp' | 'isEncrypted'>): ChatMessage => {
  const messages = getChatMessages();
  const newMessage: ChatMessage = {
    ...message,
    id: generateId(),
    timestamp: new Date(),
    isEncrypted: true,
    message: encryptData(message.message)
  };
  
  messages.push(newMessage);
  if (messages.length > 500) messages.shift();
  localStorage.setItem(DB_KEYS.CHAT, JSON.stringify(messages));
  
  return newMessage;
};

// ============================================
// XP & LEVEL SYSTEM
// ============================================

export const xpLevels: XPLevel[] = [
  { level: 1, name: 'YENI', minXP: 0, maxXP: 100, badge: 'Seedling', color: '#8B4513' },
  { level: 2, name: 'OGRENCI', minXP: 100, maxXP: 300, badge: 'Sprout', color: '#228B22' },
  { level: 3, name: 'AMATOR', minXP: 300, maxXP: 600, badge: 'Leaf', color: '#32CD32' },
  { level: 4, name: 'SEMIYETERLI', minXP: 600, maxXP: 1000, badge: 'Branch', color: '#00FF00' },
  { level: 5, name: 'YETERLI', minXP: 1000, maxXP: 1500, badge: 'Tree', color: '#00FA9A' },
  { level: 6, name: 'UZMAN', minXP: 1500, maxXP: 2200, badge: 'Flower', color: '#00CED1' },
  { level: 7, name: 'USTA', minXP: 2200, maxXP: 3000, badge: 'Star', color: '#1E90FF' },
  { level: 8, name: 'EFSANE', minXP: 3000, maxXP: 4000, badge: 'Crown', color: '#FFD700' },
  { level: 9, name: 'TANRI', minXP: 4000, maxXP: 5500, badge: 'Trophy', color: '#FF8C00' },
  { level: 10, name: 'KURUCU', minXP: 5500, maxXP: 999999, badge: 'Diamond', color: '#FF0040' }
];

export const addXP = (userId: string, amount: number): { newXP: number; newLevel: number; leveledUp: boolean } => {
  const user = getUserById(userId);
  if (!user) return { newXP: 0, newLevel: 1, leveledUp: false };
  
  const oldLevel = user.level;
  const newXP = user.xp + amount;
  
  // Find new level
  let newLevel = 1;
  for (const level of xpLevels) {
    if (newXP >= level.minXP) {
      newLevel = level.level;
    }
  }
  
  updateUser(userId, { xp: newXP, level: newLevel });
  
  return {
    newXP,
    newLevel,
    leveledUp: newLevel > oldLevel
  };
};

export const getLevelInfo = (xp: number): XPLevel => {
  for (let i = xpLevels.length - 1; i >= 0; i--) {
    if (xp >= xpLevels[i].minXP) {
      return xpLevels[i];
    }
  }
  return xpLevels[0];
};

// ============================================
// BADGE SYSTEM
// ============================================

export const checkAndAwardBadges = (userId: string): Badge[] => {
  const user = getUserById(userId);
  if (!user) return [];
  
  const newBadges: Badge[] = [];
  const existingBadgeIds = user.badges.map(b => b.id);
  
  // First Query Badge
  if (user.totalQueries >= 1 && !existingBadgeIds.includes('first_query')) {
    newBadges.push({
      id: 'first_query',
      name: 'ILK SORGU',
      description: 'Ilk sorgunuzu yaptiniz',
      icon: 'Search',
      color: '#00ffff',
      unlockedAt: new Date()
    });
  }
  
  // 100 Queries Badge
  if (user.totalQueries >= 100 && !existingBadgeIds.includes('queries_100')) {
    newBadges.push({
      id: 'queries_100',
      name: 'SORGU USTASI',
      description: '100 sorgu tamamladiniz',
      icon: 'Database',
      color: '#ff00ff',
      unlockedAt: new Date()
    });
  }
  
  // 1000 Queries Badge
  if (user.totalQueries >= 1000 && !existingBadgeIds.includes('queries_1000')) {
    newBadges.push({
      id: 'queries_1000',
      name: 'SORGU EFSANESI',
      description: '1000 sorgu tamamladiniz',
      icon: 'Crown',
      color: '#ffff00',
      unlockedAt: new Date()
    });
  }
  
  // Level 5 Badge
  if (user.level >= 5 && !existingBadgeIds.includes('level_5')) {
    newBadges.push({
      id: 'level_5',
      name: 'YETERLI',
      description: 'Seviye 5\'e ulastiniz',
      icon: 'Star',
      color: '#00ff00',
      unlockedAt: new Date()
    });
  }
  
  // Level 10 Badge
  if (user.level >= 10 && !existingBadgeIds.includes('level_10')) {
    newBadges.push({
      id: 'level_10',
      name: 'KURUCU SEVIYESI',
      description: 'Maksimum seviyeye ulastiniz',
      icon: 'Trophy',
      color: '#ff0040',
      unlockedAt: new Date()
    });
  }
  
  if (newBadges.length > 0) {
    updateUser(userId, { badges: [...user.badges, ...newBadges] });
  }
  
  return newBadges;
};

// ============================================
// QUERY CATEGORIES (Extended)
// ============================================

export const queryCategories: QueryCategory[] = [
  {
    id: 'free',
    name: 'UCRETSIZ SORGULAR',
    description: 'Tum uyeler icin ucretsiz erisim',
    isPremium: false,
    queries: [
      { 
        id: 'tc', name: 'TC Sorgu', description: 'TC Kimlik numarasi ile sorgu', 
        icon: 'User', placeholder: '11 haneli TC No', pattern: '^[0-9]{11}$', 
        requiresMembership: 'free', xpReward: 5,
        // API INTEGRATION PLACEHOLDER
        apiEndpoint: '', // <-- API URL HERE
        apiMethod: 'POST',
        apiHeaders: {} // <-- API HEADERS HERE
      },
      { 
        id: 'gsm', name: 'GSM Sorgu', description: 'Telefon numarasi ile sorgu', 
        icon: 'Phone', placeholder: '5XX XXX XXXX', pattern: '^[0-9]{10,11}$', 
        requiresMembership: 'free', xpReward: 5,
        apiEndpoint: '', apiMethod: 'POST', apiHeaders: {}
      },
      { 
        id: 'adres', name: 'Adres Sorgu', description: 'Adres bilgisi ile sorgu', 
        icon: 'MapPin', placeholder: 'Adres girin', 
        requiresMembership: 'free', xpReward: 3,
        apiEndpoint: '', apiMethod: 'POST', apiHeaders: {}
      },
      { 
        id: 'ip', name: 'IP Sorgu', description: 'IP adresi ile lokasyon sorgu', 
        icon: 'Globe', placeholder: '192.168.1.1', pattern: '^[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}$', 
        requiresMembership: 'free', xpReward: 2,
        apiEndpoint: '', apiMethod: 'GET', apiHeaders: {}
      },
    ]
  },
  {
    id: 'premium',
    name: 'PREMIUM SORGULAR',
    description: 'VIP ve uzeri uyelik gerektirir',
    isPremium: true,
    queries: [
      { 
        id: 'plaka', name: 'Plaka Sorgu', description: 'Arac plakasi ile detayli sorgu', 
        icon: 'Car', placeholder: '34 ABC 123', 
        requiresMembership: 'vip', xpReward: 10,
        apiEndpoint: '', apiMethod: 'POST', apiHeaders: {}
      },
      { 
        id: 'email', name: 'E-posta Sorgu', description: 'E-posta ile sosyal medya sorgu', 
        icon: 'Mail', placeholder: 'ornek@email.com', pattern: '^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$', 
        requiresMembership: 'vip', xpReward: 8,
        apiEndpoint: '', apiMethod: 'POST', apiHeaders: {}
      },
      { 
        id: 'iban', name: 'IBAN Sorgu', description: 'IBAN ile hesap sorgu', 
        icon: 'CreditCard', placeholder: 'TR00 0000 0000...', 
        requiresMembership: 'elmas', xpReward: 15,
        apiEndpoint: '', apiMethod: 'POST', apiHeaders: {}
      },
      { 
        id: 'pasaport', name: 'Pasaport Sorgu', description: 'Pasaport no ile sorgu', 
        icon: 'BookOpen', placeholder: 'Pasaport numarasi', 
        requiresMembership: 'elmas', xpReward: 15,
        apiEndpoint: '', apiMethod: 'POST', apiHeaders: {}
      },
      { 
        id: 'sosyalmedya', name: 'Sosyal Medya Sorgu', description: 'Tum sosyal medya platformlari', 
        icon: 'Share2', placeholder: 'Kullanici adi', 
        requiresMembership: 'elmas', xpReward: 20,
        apiEndpoint: '', apiMethod: 'POST', apiHeaders: {}
      },
      // Extended queries
      { 
        id: 'tapu', name: 'Tapu Sorgu', description: 'Tapu bilgisi sorgu', 
        icon: 'Home', placeholder: 'Ada/Parsel', 
        requiresMembership: 'elmas', xpReward: 25,
        apiEndpoint: '', apiMethod: 'POST', apiHeaders: {}
      },
      { 
        id: 'sgk', name: 'SGK Sorgu', description: 'SGK kayit sorgu', 
        icon: 'Shield', placeholder: 'TC Kimlik No', 
        requiresMembership: 'elmas', xpReward: 20,
        apiEndpoint: '', apiMethod: 'POST', apiHeaders: {}
      },
      { 
        id: 'vergi', name: 'Vergi Sorgu', description: 'Vergi kayit sorgu', 
        icon: 'DollarSign', placeholder: 'Vergi No', 
        requiresMembership: 'elmas', xpReward: 20,
        apiEndpoint: '', apiMethod: 'POST', apiHeaders: {}
      },
      { 
        id: 'ehliyet', name: 'Ehliyet Sorgu', description: 'Ehliyet bilgisi sorgu', 
        icon: 'IdCard', placeholder: 'Ehliyet No', 
        requiresMembership: 'vip', xpReward: 12,
        apiEndpoint: '', apiMethod: 'POST', apiHeaders: {}
      },
      { 
        id: 'trafikceza', name: 'Trafik Cezasi', description: 'Trafik ceza sorgu', 
        icon: 'AlertTriangle', placeholder: 'Plaka veya TC', 
        requiresMembership: 'vip', xpReward: 10,
        apiEndpoint: '', apiMethod: 'POST', apiHeaders: {}
      },
    ]
  }
];

// ============================================
// MEMBERSHIP PLANS
// ============================================

export const membershipPlans: MembershipPlan[] = [
  {
    id: 'weekly',
    name: 'HAFTALIK VIP',
    price: 250,
    duration: 7,
    type: 'weekly',
    features: [
      'Tum Ucretsiz Sorgular',
      'Premium Sorgulara Erisim',
      '7/24 Telegram Destek',
      'Sinirsiz Sorgu Hakki'
    ],
    color: '#00ffff'
  },
  {
    id: 'monthly',
    name: 'AYLIK ELMAS',
    price: 500,
    duration: 30,
    type: 'monthly',
    features: [
      'Tum Ucretsiz Sorgular',
      'Tum Premium Sorgular',
      'Oncelikli Destek',
      'Sinirsiz Sorgu Hakki',
      'API Erisimi'
    ],
    color: '#ff00ff'
  },
  {
    id: 'yearly',
    name: 'YILLIK ELMAS+',
    price: 5000,
    duration: 365,
    type: 'yearly',
    features: [
      'Tum Sorgu Turleri',
      'Ozel API Erisimi',
      '7/24 Oncelikli Destek',
      'Sinirsiz Sorgu',
      'Yillik %17 Indirim'
    ],
    color: '#ffff00'
  },
  {
    id: 'vendor',
    name: 'VENDOR / SATICI',
    price: 12000,
    duration: 36500,
    type: 'unlimited',
    features: [
      'TUM SORGULAR SINIRSIZ',
      'KENDI UYELIKLERINI SATABILIR',
      'KOMISYON KAZANIR',
      'OZEL VENDOR PANELI',
      'IP LOG YOK - GIZLILIK'
    ],
    color: '#00ff00'
  }
];

// ============================================
// PERMISSIONS
// ============================================

export const hasPermission = (user: User | null, permission: string): boolean => {
  if (!user) return false;
  if (!user.isApproved) return false; // Must be approved
  if (user.role === 'founder') return true;
  if (user.permissions.includes('*')) return true;
  return user.permissions.includes(permission);
};

export const canGrantPermissions = (user: User | null): boolean => {
  if (!user) return false;
  return user.role === 'founder' || user.role === 'admin';
};

export const canViewIpLogs = (user: User | null): boolean => {
  if (!user) return false;
  if (user.role === 'vendor') return false;
  return user.role === 'founder' || user.role === 'admin';
};

export const canApproveUsers = (user: User | null): boolean => {
  if (!user) return false;
  return user.role === 'founder' || user.role === 'admin';
};

export const isMembershipActive = (user: User): boolean => {
  if (!user.membershipExpiry) return false;
  return new Date(user.membershipExpiry) > new Date();
};

export const canAccessQuery = (user: User | null, queryRequires: 'free' | 'vip' | 'elmas'): boolean => {
  if (!user) return queryRequires === 'free';
  if (!user.isApproved) return false;
  if (user.role === 'founder' || user.role === 'admin' || user.role === 'vendor') return true;
  
  const membership = user.membershipType || 'none';
  
  if (queryRequires === 'free') return true;
  if (queryRequires === 'vip') return membership === 'vip' || membership === 'elmas' || membership === 'vendor';
  if (queryRequires === 'elmas') return membership === 'elmas' || membership === 'vendor';
  
  return false;
};

// ============================================
// SECURITY
// ============================================

export const getSecurityInfo = () => {
  return {
    status: 'SECURE',
    ddosProtection: 'AKTIF',
    ipMasking: 'AKTIF',
    encryption: '256-BIT AES',
    serverLocation: 'OFFSHORE'
  };
};

export const recordFailedLogin = (username: string): number => {
  const user = getUserByUsername(username);
  if (!user) return 0;
  
  const newAttempts = (user.loginAttempts || 0) + 1;
  const updates: Partial<User> = { loginAttempts: newAttempts };
  
  if (newAttempts >= 5) {
    const lockoutTime = new Date();
    lockoutTime.setMinutes(lockoutTime.getMinutes() + 30);
    updates.lockedUntil = lockoutTime;
  }
  
  updateUser(user.id, updates);
  return newAttempts;
};

export const resetLoginAttempts = (userId: string): void => {
  updateUser(userId, { loginAttempts: 0, lockedUntil: undefined });
};

export const isAccountLocked = (user: User): boolean => {
  if (!user.lockedUntil) return false;
  return new Date(user.lockedUntil) > new Date();
};
